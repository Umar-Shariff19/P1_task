FINAL IEEE PAPER WORKSPACE
==========================

This folder contains the authoritative, freshly verified IEEE research paper for the Industrial IoT Intrusion Detection System.

Files:
- main.tex: LaTeX manuscript formatted in IEEE two-column IEEEtran style.
- references.bib: Complete BibTeX database containing all 25 cited research references.
- figures/: High-resolution single-column IEEE plots for Detection ROC-AUC, Adversarial PGD-10 ASR, and Host Throughput Scaling.
- tables/: Table assets and templates.
- FINAL_IEEE_PAPER.zip: Self-contained Overleaf-ready upload archive.

All metrics are derived from the current repository implementation and fresh re-verification.
