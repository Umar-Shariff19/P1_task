import json
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

corpus = json.load(open(r"scratch\corpus_25_full.json", encoding="utf-8"))

print(f"Total papers: {len(corpus)}")

for p in corpus:
    idx = p["index"]
    fname = p["filename"]
    text = p["text_head"]
    
    doi_match = re.search(r'10\.\d{4,9}/[-._;()/:A-Za-z0-9]+', text)
    doi = doi_match.group(0) if doi_match else "N/A"
    
    print(f"[{idx}] {fname} | DOI: {doi}")
    lines = [l.strip() for l in text.split('\n') if l.strip()][:8]
    for line in lines:
        print("   ", line[:120])
    print("-" * 70)
