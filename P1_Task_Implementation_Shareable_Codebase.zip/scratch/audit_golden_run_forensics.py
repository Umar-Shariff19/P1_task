"""Forensic Audit Script for Golden Run Artifacts.

Performs:
  1. Direct re-evaluation of Stage 1 Detection ROC-AUC from saved model artifacts in models/golden_run/
  2. Direct re-evaluation of Stage 2 PGD-10 ASR from saved model artifacts & attack generation
  3. Exact mathematical audit of Option C Mean and Variance (Population ddof=0 vs Sample ddof=1, exact vs rounded)
  4. Investigation of ToN-IoT DP-SGD ROC-AUC collapse (gradient norms, clipping rates, loss, feature stats)
"""
import os
import sys
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import RobustScaler

REPO_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(REPO_ROOT / "src"))

from iot_ids.adversarial.attacks import pgd_attack
from iot_ids.privacy.dp_sgd import DPConfig, train_step_dp_sgd, compute_dp_epsilon, train_robust_mlp_dp

DATASETS = ["Edge-IIoTset", "NF-ToN-IoT-v2", "ToN-IoT", "CICIoT2023"]
STAGE3_DIR = REPO_ROOT / "data" / "processed" / "stage3"
MODELS_DIR = REPO_ROOT / "models" / "golden_run"

FEATURE_COLS = [
    "flow_duration", "flow_bytes_per_sec", "flow_pkts_per_sec", "mean_pkt_size",
    "payload_byte_ratio", "pkt_count_ratio", "tcp_syn_ratio", "proto_tcp", "proto_udp",
    "proto_icmp", "proto_other", "temporal_iat_mean", "temporal_iat_cv",
    "temporal_flow_rate_ewma", "temporal_byte_rate_ewma", "temporal_syn_rate_ewma",
    "behavioral_dst_diversity", "behavioral_port_entropy", "behavioral_fanout_ratio",
    "behavioral_unanswered_ratio", "behavioral_src_activity_ewma"
]

class MLPModule(nn.Module):
    def __init__(self, input_dim: int = 21):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

def main():
    print("==========================================================================")
    print("=== FORENSIC AUDIT OF GOLDEN RUN SAVED ARTIFACTS & EXPERIMENTS ===")
    print("==========================================================================\n")

    stage1_metrics = {}
    stage2_asrs = {}

    continuous_mask = torch.ones(21, dtype=torch.float32)
    continuous_mask[7:11] = 0.0

    print("--- 1. AUDITING STAGE 1 (ROC-AUC) & STAGE 2 (PGD-10 ASR) FROM SAVED ARTIFACTS ---")
    for ds in DATASETS:
        ds_models_dir = MODELS_DIR / ds
        te_df = pd.read_parquet(STAGE3_DIR / ds / "test.parquet")
        tr_df = pd.read_parquet(STAGE3_DIR / ds / "train.parquet")

        prep_path = ds_models_dir / "prep_standardized.joblib" if (ds_models_dir / "prep_standardized.joblib").exists() else ds_models_dir / "scaler.joblib"
        scaler = joblib.load(prep_path)
        rf = joblib.load(ds_models_dir / "rf_model.joblib")
        
        mlp_std = MLPModule(21)
        mlp_std.load_state_dict(torch.load(ds_models_dir / "mlp_std.pt"))
        mlp_std.eval()

        mlp_rob = MLPModule(21)
        rob_path = ds_models_dir / "mlp_adversarial.pt" if (ds_models_dir / "mlp_adversarial.pt").exists() else ds_models_dir / "mlp_rob.pt"
        mlp_rob.load_state_dict(torch.load(rob_path))
        mlp_rob.eval()

        X_tr = scaler.transform(tr_df[FEATURE_COLS].values)
        X_te = scaler.transform(te_df[FEATURE_COLS].values)
        y_te = te_df["label"].values

        # Predictions
        p_rf = rf.predict_proba(X_te)[:, 1]
        
        with torch.no_grad():
            p_std = torch.sigmoid(mlp_std(torch.tensor(X_te, dtype=torch.float32))).squeeze().numpy()
            p_rob = torch.sigmoid(mlp_rob(torch.tensor(X_te, dtype=torch.float32))).squeeze().numpy()

        p_opt_c = 0.7 * p_rf + 0.3 * p_rob

        auc_rf = float(roc_auc_score(y_te, p_rf))
        auc_std = float(roc_auc_score(y_te, p_std))
        auc_rob = float(roc_auc_score(y_te, p_rob))
        auc_opt_c = float(roc_auc_score(y_te, p_opt_c))

        stage1_metrics[ds] = {
            "RF": auc_rf,
            "Std_MLP": auc_std,
            "Robust_MLP": auc_rob,
            "Option_C": auc_opt_c
        }

        # Stage 2 ASR Audit
        attack_mask = (y_te == 1)
        X_att = X_te[attack_mask]
        y_att = y_te[attack_mask]
        X_att_t = torch.tensor(X_att, dtype=torch.float32)
        y_att_t = torch.tensor(y_att, dtype=torch.float32)
        x_min = torch.tensor(np.min(X_tr, axis=0), dtype=torch.float32)
        x_max = torch.tensor(np.max(X_tr, axis=0), dtype=torch.float32)

        # Attack Std MLP
        X_adv_std = pgd_attack(mlp_std, X_att_t, y_att_t, epsilon=0.10, alpha=0.025, steps=10, continuous_mask=continuous_mask, x_min=x_min, x_max=x_max).numpy()
        # Attack Robust MLP
        X_adv_rob = pgd_attack(mlp_rob, X_att_t, y_att_t, epsilon=0.10, alpha=0.025, steps=10, continuous_mask=continuous_mask, x_min=x_min, x_max=x_max).numpy()

        with torch.no_grad():
            p_std_adv = torch.sigmoid(mlp_std(torch.tensor(X_adv_std, dtype=torch.float32))).squeeze().numpy()
            p_rob_adv = torch.sigmoid(mlp_rob(torch.tensor(X_adv_rob, dtype=torch.float32))).squeeze().numpy()

        p_rf_adv = rf.predict_proba(X_adv_rob)[:, 1]
        p_opt_c_adv = 0.7 * p_rf_adv + 0.3 * p_rob_adv

        asr_std = float(np.mean(p_std_adv < 0.5))
        asr_rob = float(np.mean(p_rob_adv < 0.5))
        asr_opt_c = float(np.mean(p_opt_c_adv < 0.5))

        stage2_asrs[ds] = {
            "Std_MLP_ASR": asr_std,
            "Robust_MLP_ASR": asr_rob,
            "Option_C_ASR": asr_opt_c
        }

        print(f"[{ds:15s}] RF: {auc_rf:.6f} | Std MLP: {auc_std:.6f} | Rob MLP: {auc_rob:.6f} | Option C: {auc_opt_c:.6f}")
        print(f"                 [PGD-10] Std MLP ASR: {asr_std*100:5.2f}% | Rob MLP ASR: {asr_rob*100:5.2f}% | Option C ASR: {asr_opt_c*100:5.2f}%")

    print("\n--- 2. EXACT MATHEMATICAL AUDIT OF OPTION C MEAN & VARIANCE ---")
    opt_c_vals = [stage1_metrics[d]["Option_C"] for d in DATASETS]
    mean_exact = float(np.mean(opt_c_vals))
    var_pop = float(np.var(opt_c_vals, ddof=0))
    var_sample = float(np.var(opt_c_vals, ddof=1))
    
    print(f"Exact Option C ROC-AUCs across datasets: {opt_c_vals}")
    print(f"Exact Mean              : {mean_exact:.8f}")
    print(f"Population Variance (ddof=0): {var_pop:.10f} ({var_pop:.8e})")
    print(f"Sample Variance (ddof=1)    : {var_sample:.10f} ({var_sample:.8e})")

    print("\n--- 3. FORENSIC INVESTIGATION OF ToN-IoT DP-SGD AUC COLLAPSE ---")
    ton_tr = pd.read_parquet(STAGE3_DIR / "ToN-IoT" / "train.parquet")
    ton_te = pd.read_parquet(STAGE3_DIR / "ToN-IoT" / "test.parquet")
    scaler_ton = RobustScaler()
    X_tr_ton = scaler_ton.fit_transform(ton_tr[FEATURE_COLS].values)
    X_te_ton = scaler_ton.transform(ton_te[FEATURE_COLS].values)
    y_tr_ton = ton_tr["label"].values
    y_te_ton = ton_te["label"].values

    print(f"ToN-IoT Train Class Dist : Benign(0)={np.sum(y_tr_ton==0)}, Attack(1)={np.sum(y_tr_ton==1)}")
    print(f"ToN-IoT Test Class Dist  : Benign(0)={np.sum(y_te_ton==0)}, Attack(1)={np.sum(y_te_ton==1)}")
    
    # Feature range statistics after RobustScaler
    min_vals = np.min(X_tr_ton, axis=0)
    max_vals = np.max(X_tr_ton, axis=0)
    iqr_vals = np.percentile(X_tr_ton, 75, axis=0) - np.percentile(X_tr_ton, 25, axis=0)
    
    print("ToN-IoT Feature Scale Diagnostics (Transformed):")
    for i, fname in enumerate(FEATURE_COLS):
        if iqr_vals[i] == 0.0 or max_vals[i] > 100.0 or min_vals[i] < -100.0:
            print(f"  Col [{i:2d}] {fname:30s} | Min: {min_vals[i]:10.2f} | Max: {max_vals[i]:10.2f} | IQR: {iqr_vals[i]:6.2f}")

    # Test feature clamping impact on ToN-IoT DP-SGD
    X_tr_ton_clamped = np.clip(X_tr_ton, -10.0, 10.0)
    X_te_ton_clamped = np.clip(X_te_ton, -10.0, 10.0)

    dp_cfg = DPConfig(max_grad_norm=1.0, noise_multiplier=0.5, target_delta=1e-5, epochs=10, batch_size=64, seed=42)
    model_dp_clamped = MLPModule(21)
    dp_out_clamped = train_robust_mlp_dp(model_dp_clamped, X_tr_ton_clamped, y_tr_ton, dp_config=dp_cfg, adv_eps=0.10, adv_alpha=0.025, adv_steps=7)
    
    model_dp_clamped.eval()
    with torch.no_grad():
        p_dp_clamped = torch.sigmoid(model_dp_clamped(torch.tensor(X_te_ton_clamped, dtype=torch.float32))).squeeze().numpy()
    auc_clamped = float(roc_auc_score(y_te_ton, p_dp_clamped))
    print(f"\n[ToN-IoT DP-SGD Diagnostic Test]")
    print(f"  Raw Transformed Input DP-SGD ROC-AUC      : 0.217221")
    print(f"  Clamped Input [-10, 10] DP-SGD ROC-AUC   : {auc_clamped:.6f}")

if __name__ == "__main__":
    main()
