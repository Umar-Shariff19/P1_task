"""Audit SHAP and Federated Learning results against manuscript claims."""
import json
from pathlib import Path

# --- SHAP RESULTS ---
shap_data = json.loads(Path('reports/standardized/xai/shap_results.json').read_text(encoding='utf-8'))
print("=== SHAP RESULTS ===")
for ds in ['ToN-IoT', 'Edge-IIoTset', 'NF-ToN-IoT-v2', 'CICIoT2023']:
    if ds in shap_data:
        d = shap_data[ds]
        rho_key = None
        for k in d:
            if 'spearman' in k.lower() or 'rho' in k.lower() or 'correlation' in k.lower():
                rho_key = k
                break
        if rho_key:
            print(f"  {ds}: {rho_key} = {d[rho_key]}")
        else:
            print(f"  {ds}: keys = {list(d.keys())}")
    else:
        print(f"  {ds}: NOT FOUND")

# --- FEDERATED RESULTS ---
print("\n=== FEDERATED LEARNING RESULTS ===")
fed_data = json.loads(Path('reports/standardized/federated/federated_results.json').read_text(encoding='utf-8'))
print(json.dumps(fed_data, indent=2)[:3000])

# --- ASR Summary from the standardized adversarial file ---
print("\n=== ADVERSARIAL ASR SUMMARY (standardized_21) ===")
adv_data = json.loads(Path('reports/standardized/adversarial/adversarial_results.json').read_text(encoding='utf-8'))
for ds in ['ToN-IoT', 'Edge-IIoTset', 'NF-ToN-IoT-v2', 'CICIoT2023']:
    if ds in adv_data:
        std = adv_data[ds].get('standard_mlp', [])
        adv = adv_data[ds].get('adversarial_mlp', [])
        print(f"\n  --- {ds} ---")
        for entry in std:
            if isinstance(entry, dict) and entry.get('attack') == 'PGD' and abs(entry.get('epsilon', 0) - 0.1) < 0.01:
                asr = entry.get('attack_success_rate', 'N/A')
                cauc = entry.get('clean_auc', 'N/A')
                print(f"  Standard MLP PGD eps=0.1: ASR={asr}, clean_auc={cauc}")
        for entry in adv:
            if isinstance(entry, dict) and entry.get('attack') == 'PGD' and abs(entry.get('epsilon', 0) - 0.1) < 0.01:
                asr = entry.get('attack_success_rate', 'N/A')
                cauc = entry.get('clean_auc', 'N/A')
                print(f"  Robust MLP PGD eps=0.1: ASR={asr}, clean_auc={cauc}")

# --- Check Milestone 3A final results JSON for 93.85 ---
print("\n=== MILESTONE 3A FINAL RESULTS (checking for 93.85 origin) ===")
m3a = json.loads(Path('reports/standardized/milestone_3a_final_results.json').read_text(encoding='utf-8'))
txt = json.dumps(m3a)
import re
for m in re.finditer(r'93\.85|0\.9385', txt):
    start = max(0, m.start() - 150)
    end = min(len(txt), m.end() + 150)
    print(f"  Context: ...{txt[start:end]}...")
