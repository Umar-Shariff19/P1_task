with open(r"c:\Users\umari\Documents\P1_task_Implementation\ieee_paper_draft\sections\related_work.tex", 'r', encoding='utf-8') as f:
    rw = f.read()

with open(r"c:\Users\umari\Documents\P1_task_Implementation\ieee_paper_draft\tables\research_gap.tex", 'r', encoding='utf-8') as f:
    tbl = f.read()

text = rw + "\n" + tbl

c1 = text.count("\\\\%")
c2 = text.count("\\textbf{**")
c3 = text.count("P\\_{")
c4 = text.count("\\\\_")
c5 = text.count("**")

print("=== FORBIDDEN PATTERN AUDIT FOR STEP 3 ===")
print("Double backslash percent:", c1)
print("Textbf markdown stars:", c2)
print("Escaped P subscript:", c3)
print("Double escaped underscore:", c4)
print("Markdown stars:", c5)
