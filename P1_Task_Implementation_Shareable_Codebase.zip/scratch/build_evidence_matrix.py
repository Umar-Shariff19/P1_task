import os
import sys
import pypdf
import json

sys.stdout.reconfigure(encoding='utf-8')

pdf_dir = r"paper_support\Literature paper"
files = sorted(os.listdir(pdf_dir))

paper_db = []

for idx, f in enumerate(files, 1):
    path = os.path.join(pdf_dir, f)
    reader = pypdf.PdfReader(path)
    num_pages = len(reader.pages)
    text_p1_3 = ""
    for i in range(min(3, num_pages)):
        t = reader.pages[i].extract_text()
        if t:
            text_p1_3 += t + "\n"
    
    # Simple extraction of title/header
    paper_info = {
        "index": idx,
        "filename": f,
        "pages": num_pages,
        "sample_text": text_p1_3[:1500]
    }
    paper_db.append(paper_info)

with open(r"scratch\parsed_25_papers.json", "w", encoding="utf-8") as out:
    json.dump(paper_db, out, indent=2)

print(f"Parsed metadata for {len(paper_db)} files.")
