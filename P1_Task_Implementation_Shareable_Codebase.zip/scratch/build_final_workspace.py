import os
import zipfile

root_dir = r'C:\Users\umari\Documents\P1_task_Implementation'
paper_dir = os.path.join(root_dir, 'FINAL_IEEE_PAPER')
fig_dir = os.path.join(paper_dir, 'figures')
tbl_dir = os.path.join(paper_dir, 'tables')

os.makedirs(fig_dir, exist_ok=True)
os.makedirs(tbl_dir, exist_ok=True)

# 1. Create README.txt
readme_content = """FINAL IEEE PAPER WORKSPACE
==========================

This folder contains the authoritative, freshly verified IEEE research paper for the Industrial IoT Intrusion Detection System.

Files:
- main.tex: LaTeX manuscript formatted in IEEE two-column IEEEtran style.
- references.bib: Complete BibTeX database containing all 25 cited research references.
- figures/: High-resolution single-column IEEE plots for Detection ROC-AUC, Adversarial PGD-10 ASR, and Host Throughput Scaling.
- tables/: Table assets and templates.
- FINAL_IEEE_PAPER.zip: Self-contained Overleaf-ready upload archive.

All metrics are derived from the current repository implementation and fresh re-verification.
"""

with open(os.path.join(paper_dir, 'README.txt'), 'w', encoding='utf-8') as f:
    f.write(readme_content)

# 2. Create FINAL_IEEE_PAPER.zip inside FINAL_IEEE_PAPER and at root
zip_path_root = os.path.join(root_dir, 'FINAL_IEEE_PAPER.zip')
zip_path_local = os.path.join(paper_dir, 'FINAL_IEEE_PAPER.zip')

files_to_zip = [
    'main.tex',
    'references.bib',
    'README.txt',
    os.path.join('figures', 'detection_performance.png'),
    os.path.join('figures', 'adversarial_asr.png'),
    os.path.join('figures', 'runtime_throughput.png')
]

for target_zip in [zip_path_root, zip_path_local]:
    with zipfile.ZipFile(target_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for rel_path in files_to_zip:
            full_path = os.path.join(paper_dir, rel_path)
            if os.path.exists(full_path):
                zf.write(full_path, arcname=rel_path)

print(f'Successfully built {zip_path_root} and {zip_path_local}.')
