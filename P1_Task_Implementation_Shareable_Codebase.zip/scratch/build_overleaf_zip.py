import os
import zipfile

zip_path = r'final_ieee_paper\final_overleaf.zip'
base_dir = r'final_ieee_paper'

files_to_zip = [
    'main.tex',
    'references.bib',
    os.path.join('figures', 'detection_performance.png'),
    os.path.join('figures', 'adversarial_asr.png'),
    os.path.join('figures', 'runtime_throughput.png')
]

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for rel_path in files_to_zip:
        full_path = os.path.join(base_dir, rel_path)
        if os.path.exists(full_path):
            zf.write(full_path, arcname=rel_path)
            print(f'Added to ZIP: {rel_path}')
        else:
            print(f'WARNING: File not found: {full_path}')

print(f'\nSuccessfully created Overleaf ZIP package: {zip_path}')
