import json
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

pdf_extracts = json.load(open(r"scratch\pdf_forensic_extracts.json", encoding="utf-8"))

legacy_keys = ["alrashdi", "mehedi", "kumar", "hussain"]

print("=== CHECKING LEGACY CITATIONS IN 21 CORPUS PAPERS ===")

# Print the exact title and authors of each of the 21 paper groups
for idx, p in enumerate(pdf_extracts, 1):
    label = p["label"]
    lines = [l.strip() for l in p["text_sample"].split('\n') if l.strip()]
    print(f"[{idx}] {label}")
    for line in lines[:5]:
        print("    ", line[:100])
    print("-" * 60)
