import os

files = [
    r"c:\Users\umari\Documents\P1_task_Implementation\ieee_paper_draft\sections\abstract.tex",
    r"c:\Users\umari\Documents\P1_task_Implementation\ieee_paper_draft\sections\introduction.tex"
]

total_double_percent = 0
total_textbf_markdown = 0
total_p_escaped_underscore_subscript = 0
total_double_escaped_underscore = 0
total_markdown_stars = 0

for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    dp = content.count("\\\\%")
    tb = content.count("\\textbf{**")
    pu = content.count("P\\_{")
    eu = content.count("\\\\_")
    ms = content.count("**")
    
    total_double_percent += dp
    total_textbf_markdown += tb
    total_p_escaped_underscore_subscript += pu
    total_double_escaped_underscore += eu
    total_markdown_stars += ms
    
    print(f"=== RAW DISK AUDIT: {os.path.basename(fpath)} ===")
    print(f"  \\\\% occurrences: {dp}")
    print(f"  \\textbf{{** occurrences: {tb}")
    print(f"  P\\_{{ occurrences: {pu}")
    print(f"  \\\\_ occurrences: {eu}")
    print(f"  Markdown ** occurrences: {ms}")

print("\n=== TOTAL OVERALL OCCURRENCES ===")
print(f"\\\\%              = {total_double_percent}")
print(f"\\textbf{{**       = {total_textbf_markdown}")
print(f"P\\_{{            = {total_p_escaped_underscore_subscript}")
print(f"\\\\_             = {total_double_escaped_underscore}")
print(f"Markdown **     = {total_markdown_stars}")
