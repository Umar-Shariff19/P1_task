import sys
import time
import json
import torch
import numpy as np
from pathlib import Path

ROOT_DIR = Path(r"c:\Users\umari\Documents\P1_task_Implementation")
sys.path.insert(0, str(ROOT_DIR / "src"))

from iot_ids.runtime.engine import InferenceEngine

FEATURE_COLS = [
    "flow_duration", "flow_bytes_per_sec", "flow_pkts_per_sec", "mean_pkt_size",
    "payload_byte_ratio", "pkt_count_ratio", "tcp_syn_ratio", "proto_tcp", "proto_udp",
    "proto_icmp", "proto_other", "temporal_iat_mean", "temporal_iat_cv",
    "temporal_flow_rate_ewma", "temporal_byte_rate_ewma", "temporal_syn_rate_ewma",
    "behavioral_dst_diversity", "behavioral_port_entropy", "behavioral_fanout_ratio",
    "behavioral_unanswered_ratio", "behavioral_src_activity_ewma"
]

def run_benchmark():
    print("=== CONTROLLED RUNTIME BENCHMARK ===")
    print("PyTorch Version:", torch.__version__)
    print("PyTorch Num Threads:", torch.get_num_threads())
    
    models_dir = ROOT_DIR / "models" / "golden_run"
    engine = InferenceEngine(profile="standardized_21", dataset="ToN-IoT", models_base_dir=models_dir)
    sample_feat_dict = {feat: 1.0 for feat in FEATURE_COLS}

    # Warmup runs (50 iterations)
    print("Running 50 warmup iterations for N=1024...")
    batch_1024 = [sample_feat_dict] * 1024
    for _ in range(50):
        _ = engine.predict(batch_1024, explain=False)

    # Test N=1024 across 50 controlled trials
    print("Executing 50 controlled trials for N=1024...")
    latencies = []
    throughputs = []
    for i in range(50):
        t_s = time.perf_counter()
        _ = engine.predict(batch_1024, explain=False)
        t_e = time.perf_counter()
        lat_ms = (t_e - t_s) * 1000.0
        tp = 1024.0 / (lat_ms / 1000.0)
        latencies.append(lat_ms)
        throughputs.append(tp)

    mean_lat = np.mean(latencies)
    std_lat = np.std(latencies)
    min_lat = np.min(latencies)
    max_lat = np.max(latencies)

    mean_tp = np.mean(throughputs)
    std_tp = np.std(throughputs)
    max_tp = np.max(throughputs) # Peak throughput (cleanest trial)

    print(f"\n--- N=1024 Controlled Results (50 Trials) ---")
    print(f"Mean Batch Latency: {mean_lat:.2f} ms (std: {std_lat:.2f} ms, min: {min_lat:.2f} ms, max: {max_lat:.2f} ms)")
    print(f"Mean Throughput:    {mean_tp:.1f} samples/s (std: {std_tp:.1f} samples/s)")
    print(f"Peak Throughput:    {max_tp:.1f} samples/s")

    # Run for all batch sizes under controlled 30 trials each
    all_results = {}
    for b_size in [1, 32, 64, 128, 256, 512, 1024]:
        b_in = [sample_feat_dict] * b_size
        # Warmup
        for _ in range(10):
            _ = engine.predict(b_in, explain=False)
        b_lats = []
        b_tps = []
        for _ in range(30):
            t_s = time.perf_counter()
            _ = engine.predict(b_in, explain=False)
            t_e = time.perf_counter()
            l_ms = (t_e - t_s) * 1000.0
            tp_val = b_size / (l_ms / 1000.0)
            b_lats.append(l_ms)
            b_tps.append(tp_val)
        
        all_results[str(b_size)] = {
            "batch_size": b_size,
            "mean_batch_latency_ms": float(np.mean(b_lats)),
            "std_batch_latency_ms": float(np.std(b_lats)),
            "min_batch_latency_ms": float(np.min(b_lats)),
            "per_sample_latency_ms": float(np.mean(b_lats) / b_size),
            "mean_throughput": float(np.mean(b_tps)),
            "peak_throughput": float(np.max(b_tps))
        }

    print("\n--- Summary Across Batch Sizes (Controlled) ---")
    for b_s, res in all_results.items():
        print(f"Batch {int(b_s):4d}: Latency={res['mean_batch_latency_ms']:.2f}ms (min {res['min_batch_latency_ms']:.2f}ms) | Per-Sample={res['per_sample_latency_ms']:.4f}ms | Mean TP={res['mean_throughput']:7.1f} samples/s | Peak TP={res['peak_throughput']:7.1f} samples/s")

    out_file = ROOT_DIR / "reports" / "final_forensic_audit" / "controlled_runtime_results.json"
    with open(out_file, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\nSaved controlled benchmark to {out_file}")

if __name__ == "__main__":
    run_benchmark()
