import os
import sys
import pypdf

# Set stdout encoding to utf-8
sys.stdout.reconfigure(encoding='utf-8')

pdf_dir = r"paper_support\Literature paper"
files = sorted(os.listdir(pdf_dir))

out_file = r"scratch\literature_full_summary.txt"

with open(out_file, "w", encoding="utf-8") as out:
    out.write(f"Total files in directory: {len(files)}\n\n")
    
    for idx, f in enumerate(files, 1):
        path = os.path.join(pdf_dir, f)
        try:
            reader = pypdf.PdfReader(path)
            num_pages = len(reader.pages)
            text = ""
            for i in range(min(4, num_pages)):
                t = reader.pages[i].extract_text()
                if t:
                    text += f"\n--- PAGE {i+1} ---\n" + t
            out.write(f"[{idx}] {f} (Pages: {num_pages})\n")
            out.write(text[:2500] + "\n")
            out.write("="*80 + "\n\n")
        except Exception as e:
            out.write(f"[{idx}] {f} ERROR: {e}\n\n")

print("Saved all 25 PDF summaries to scratch/literature_full_summary.txt")
