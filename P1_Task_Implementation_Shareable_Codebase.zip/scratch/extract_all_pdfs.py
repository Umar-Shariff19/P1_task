import os
import pypdf

pdf_dir = r"paper_support\Literature paper"
files = sorted(os.listdir(pdf_dir))

print(f"Total files in directory: {len(files)}")

for idx, f in enumerate(files, 1):
    path = os.path.join(pdf_dir, f)
    try:
        reader = pypdf.PdfReader(path)
        num_pages = len(reader.pages)
        text = ""
        for i in range(min(5, num_pages)):
            t = reader.pages[i].extract_text()
            if t:
                text += f"\n--- PAGE {i+1} ---\n" + t
        print(f"[{idx}] {f} (Pages: {num_pages}, Text len: {len(text)})")
        print(text[:1200])
        print("="*70 + "\n")
    except Exception as e:
        print(f"[{idx}] {f} ERROR: {e}")
