import os
import sys
import json
import pypdf

sys.stdout.reconfigure(encoding='utf-8')

pdf_dir = r"paper_support\Literature paper"
files = sorted(os.listdir(pdf_dir))

corpus = []

for idx, fname in enumerate(files, 1):
    path = os.path.join(pdf_dir, fname)
    reader = pypdf.PdfReader(path)
    full_text = ""
    for page in reader.pages:
        t = page.extract_text()
        if t:
            full_text += t + "\n"
    
    # Store first 3000 chars for analysis
    corpus.append({
        "index": idx,
        "filename": fname,
        "pages": len(reader.pages),
        "text_head": full_text[:2500],
        "full_len": len(full_text)
    })

print(f"Loaded {len(corpus)} papers.")

with open(r"scratch\corpus_25_full.json", "w", encoding="utf-8") as f:
    json.dump(corpus, f, indent=2)
