"""Extract title, authors, and abstract from each unique literature PDF."""
import hashlib
import json
from pathlib import Path

import fitz  # PyMuPDF

lit_dir = Path("paper_support/Literature paper")
files = sorted(lit_dir.glob("*.pdf"))

# Deduplicate
seen_hashes = {}
unique_files = []
for f in files:
    h = hashlib.md5(f.read_bytes()).hexdigest()
    if h not in seen_hashes:
        seen_hashes[h] = f.name
        unique_files.append(f)
    else:
        print(f"SKIP duplicate: {f.name} == {seen_hashes[h]}")

print(f"\nProcessing {len(unique_files)} unique papers...\n")

results = []
for i, pdf_path in enumerate(unique_files, 1):
    try:
        doc = fitz.open(str(pdf_path))
        # Extract first 2 pages of text
        text = ""
        for page_num in range(min(2, len(doc))):
            text += doc[page_num].get_text()
        doc.close()

        # Take first 3000 chars for title/abstract extraction
        snippet = text[:3000].replace("\r", "").strip()
        
        print(f"=== PAPER {i}: {pdf_path.name} ===")
        print(snippet[:1500])
        print("---END SNIPPET---\n")
        
        results.append({
            "index": i,
            "filename": pdf_path.name,
            "first_1500_chars": snippet[:1500]
        })
    except Exception as e:
        print(f"ERROR reading {pdf_path.name}: {e}")
        results.append({
            "index": i,
            "filename": pdf_path.name,
            "error": str(e)
        })

# Save for reference
with open("paper_support/literature_extracts.json", "w") as f:
    json.dump(results, f, indent=2, ensure_ascii=False)

print(f"\nDone. Extracted {len(results)} papers.")
