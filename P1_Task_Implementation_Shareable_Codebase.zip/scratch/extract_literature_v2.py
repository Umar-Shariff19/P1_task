"""Extract title/abstract from PDFs that had encoding errors - using UTF-8 output."""
import hashlib
from pathlib import Path
import pymupdf

lit_dir = Path("paper_support/Literature paper")

# Papers that errored: paper1, paper10, paper13, paper14, paper15, paper16, paper17
# paper2, paper4, paper5, paper6, paper7, paper8
problem_papers = [
    "paper1-IET Information Security - 2025 - Ma - Backdoor Attack and Defense Methods for AI Based IoT Intrusion Detection System.pdf",
    "paper10.pdf", "paper13.pdf", "paper14.pdf", "paper15.pdf",
    "paper16.pdf", "paper17.pdf", "paper2.pdf", "paper4.pdf",
    "paper5.pdf", "paper6.pdf", "paper7.pdf", "paper8.pdf"
]

for fname in problem_papers:
    fp = lit_dir / fname
    if not fp.exists():
        continue
    try:
        doc = pymupdf.open(str(fp))
        text = ""
        for page_num in range(min(2, len(doc))):
            text += doc[page_num].get_text()
        doc.close()
        snippet = text[:1500].replace("\r", "").strip()
        # Replace problematic chars
        snippet = snippet.encode('ascii', errors='replace').decode('ascii')
        print(f"=== {fname} ===")
        print(snippet)
        print("---END---\n")
    except Exception as e:
        print(f"FATAL ERROR {fname}: {e}\n")
