import os
import zipfile

root_dir = r'C:\Users\umari\Documents\P1_task_Implementation'
paper_dir = os.path.join(root_dir, 'FINAL_IEEE_PAPER')
fig_dir = os.path.join(paper_dir, 'figures')
tbl_dir = os.path.join(paper_dir, 'tables')

os.makedirs(fig_dir, exist_ok=True)
os.makedirs(tbl_dir, exist_ok=True)

# 1. Create README.md
readme_content = """# FINAL IEEE RESEARCH PAPER - OVERLEAF PROJECT

This folder contains the complete, editable IEEE LaTeX project for the manuscript:

**Title**: *An Adversarially Robust, Differentially Private, and Explainable Ensemble Framework for Industrial IoT Intrusion Detection*

## Project Structure
- `main.tex`: Primary LaTeX manuscript source formatted in standard IEEE two-column `IEEEtran` layout.
- `references.bib`: BibTeX bibliography database containing all 25 cited research references.
- `figures/`: High-resolution IEEE single-column figures:
  - `detection_performance.png`: Detection ROC-AUC comparison across models and datasets.
  - `adversarial_asr.png`: Adversarial PGD-10 Attack Success Rate ($\epsilon=0.1$).
  - `runtime_throughput.png`: Host inference throughput scaling across batch sizes $N \in \{1, \dots, 1024\}$.
- `tables/`: Table assets and templates.
- `FINAL_IEEE_PAPER_Overleaf.zip`: Self-contained Overleaf-ready upload package.

## Overleaf Compilation Instructions
1. Download `FINAL_IEEE_PAPER_Overleaf.zip`.
2. Log in to [Overleaf](https://www.overleaf.com/).
3. Click **New Project** -> **Upload Project**.
4. Select `FINAL_IEEE_PAPER_Overleaf.zip`.
5. Set main document to `main.tex` and compiler to **pdfLaTeX**.
6. Click **Recompile**.
"""

with open(os.path.join(paper_dir, 'README.md'), 'w', encoding='utf-8') as f:
    f.write(readme_content)

# 2. Build FINAL_IEEE_PAPER_Overleaf.zip
zip_path_root = os.path.join(root_dir, 'FINAL_IEEE_PAPER_Overleaf.zip')
zip_path_local = os.path.join(paper_dir, 'FINAL_IEEE_PAPER_Overleaf.zip')

files_to_zip = [
    'main.tex',
    'references.bib',
    'README.md',
    os.path.join('figures', 'detection_performance.png'),
    os.path.join('figures', 'adversarial_asr.png'),
    os.path.join('figures', 'runtime_throughput.png')
]

for target_zip in [zip_path_root, zip_path_local]:
    with zipfile.ZipFile(target_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for rel_path in files_to_zip:
            full_path = os.path.join(paper_dir, rel_path)
            if os.path.exists(full_path):
                zf.write(full_path, arcname=rel_path)
                print(f'Zipped: {rel_path} into {os.path.basename(target_zip)}')

print('Successfully finalized IEEE Overleaf project and generated ZIP packages.')
