import matplotlib.pyplot as plt
import numpy as np
import os

os.makedirs(r'final_ieee_paper\figures', exist_ok=True)

# Set IEEE style parameters
plt.rcParams['font.sans-serif'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 8
plt.rcParams['axes.labelsize'] = 8
plt.rcParams['axes.titlesize'] = 9
plt.rcParams['xtick.labelsize'] = 7
plt.rcParams['ytick.labelsize'] = 7
plt.rcParams['legend.fontsize'] = 7
plt.rcParams['figure.titlesize'] = 10

# Figure 1: Detection Performance
fig, ax = plt.subplots(figsize=(3.5, 2.5), dpi=300)
datasets = ['Edge-IIoT', 'NF-ToN-v2', 'ToN-IoT', 'CICIoT2023']
x = np.arange(len(datasets))
width = 0.2

rf = [0.9995, 0.9940, 1.0000, 0.9968]
std_mlp = [0.8443, 0.8398, 0.7745, 0.9776]
rob_mlp = [0.8002, 0.8299, 0.8063, 0.9884]
opt_c = [0.9988, 0.9927, 1.0000, 0.9965]

ax.bar(x - 1.5*width, rf, width, label='Random Forest', color='#1f77b4')
ax.bar(x - 0.5*width, std_mlp, width, label='Std MLP', color='#ff7f0e')
ax.bar(x + 0.5*width, rob_mlp, width, label='Robust MLP', color='#2ca02c')
ax.bar(x + 1.5*width, opt_c, width, label='Option C Ensemble', color='#d62728')

ax.set_ylabel('ROC-AUC Score')
ax.set_title('Detection ROC-AUC Across Datasets')
ax.set_xticks(x)
ax.set_xticklabels(datasets)
ax.set_ylim(0.7, 1.02)
ax.legend(loc='lower left', framealpha=0.9)
ax.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig(r'final_ieee_paper\figures\detection_performance.png')
plt.close()

# Figure 2: Adversarial Robustness ASR
fig, ax = plt.subplots(figsize=(3.5, 2.5), dpi=300)
std_asr = [0.000, 0.538, 0.023, 0.023]
rob_asr = [0.000, 0.480, 0.025, 0.013]
optc_asr = [0.038, 0.040, 0.000, 0.012]

ax.bar(x - width, std_asr, width, label='Std MLP', color='#ff7f0e')
ax.bar(x, rob_asr, width, label='Robust MLP', color='#2ca02c')
ax.bar(x + width, optc_asr, width, label='Option C Ensemble', color='#d62728')

ax.set_ylabel('PGD-10 Attack Success Rate (ASR)')
ax.set_title('Adversarial PGD-10 ASR (epsilon=0.1)')
ax.set_xticks(x)
ax.set_xticklabels(datasets)
ax.set_ylim(0.0, 0.6)
ax.legend(loc='upper right', framealpha=0.9)
ax.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig(r'final_ieee_paper\figures\adversarial_asr.png')
plt.close()

# Figure 3: Runtime Throughput
fig, ax = plt.subplots(figsize=(3.5, 2.5), dpi=300)
batch_sizes = [1, 32, 64, 128, 256, 512, 1024]
throughputs = [14.4, 583.3, 1376.1, 2742.3, 4189.0, 8409.5, 16504.7]

ax.plot(batch_sizes, throughputs, marker='o', linewidth=1.5, markersize=4, color='#1f77b4')
ax.set_xscale('log', base=2)
ax.set_yscale('log')
ax.set_xlabel('Batch Size (N)')
ax.set_ylabel('Throughput (samples/sec)')
ax.set_title('Host Inference Throughput Scaling')
ax.grid(True, which='both', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig(r'final_ieee_paper\figures\runtime_throughput.png')
plt.close()

print('Successfully generated 3 IEEE single-column figures in final_ieee_paper/figures/.')
