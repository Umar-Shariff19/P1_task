"""Generates 8 Individual Academic Visual Assets for PowerPoint Presentation.

All assets are saved as high-res 300 DPI PNG images in PPT/assets/.
Strictly no interpretations, no conclusions, no fake data.
"""

from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

OUTPUT_DIR = Path("PPT/assets")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Shared styling constants
FONT_FAMILY = "sans-serif"
COLOR_TITLE = "#0F172A"       # Dark slate
COLOR_BG = "#FFFFFF"          # Pure white
COLOR_GRID = "#E2E8F0"        # Soft grey
COLOR_BLUE = "#2563EB"        # Academic royal blue
COLOR_RED = "#DC2626"         # Crimson red
COLOR_GREEN = "#16A34A"       # Forest green
COLOR_SLATE = "#475569"       # Muted slate
COLOR_HEADER_BG = "#F1F5F9"   # Table header light grey
COLOR_ALT_ROW = "#F8FAFC"     # Alternating table row grey

plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
plt.rcParams["font.family"] = "sans-serif"


# -----------------------------------------------------------------------------
# ASSET 1: WITHIN-DOMAIN PERFORMANCE CHART
# -----------------------------------------------------------------------------
def generate_asset_1():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7, 3.8), dpi=300, facecolor=COLOR_BG)
    fig.suptitle("Within-Domain Detection Performance", fontsize=13, fontweight="bold", color=COLOR_TITLE, y=0.98)
    
    # Subplot 1: Macro F1
    ax1.set_facecolor(COLOR_BG)
    bars1 = ax1.bar(["Macro F1"], [0.986], color=COLOR_BLUE, width=0.4, edgecolor=COLOR_TITLE, linewidth=1)
    ax1.set_ylim(0, 1.15)
    ax1.set_ylabel("Score", fontsize=10, fontweight="bold", color=COLOR_SLATE)
    ax1.grid(axis="y", linestyle="--", alpha=0.5, color=COLOR_GRID)
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.text(0, 0.986 + 0.03, "0.986", ha="center", va="bottom", fontsize=11, fontweight="bold", color=COLOR_BLUE)

    # Subplot 2: False Positive Rate
    ax2.set_facecolor(COLOR_BG)
    bars2 = ax2.bar(["False Positive Rate"], [1.6], color=COLOR_GREEN, width=0.4, edgecolor=COLOR_TITLE, linewidth=1)
    ax2.set_ylim(0, 5.0)
    ax2.set_ylabel("Percentage (%)", fontsize=10, fontweight="bold", color=COLOR_SLATE)
    ax2.grid(axis="y", linestyle="--", alpha=0.5, color=COLOR_GRID)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)
    ax2.text(0, 1.6 + 0.15, "1.6%", ha="center", va="bottom", fontsize=11, fontweight="bold", color=COLOR_GREEN)

    plt.tight_layout(rect=[0, 0, 1, 0.92])
    path = OUTPUT_DIR / "asset_1_within_domain_performance.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Asset 1: {path}")


# -----------------------------------------------------------------------------
# ASSET 2: CROSS-DOMAIN ROC-AUC COMPARISON
# -----------------------------------------------------------------------------
def generate_asset_2():
    fig, ax = plt.subplots(figsize=(6.5, 4.0), dpi=300, facecolor=COLOR_BG)
    ax.set_facecolor(COLOR_BG)
    
    categories = ["Zero-Shot", "5% Target Adaptation"]
    values = [0.4630, 0.9920]
    colors = [COLOR_RED, COLOR_BLUE]
    
    bars = ax.bar(categories, values, color=colors, width=0.45, edgecolor=COLOR_TITLE, linewidth=1.2, zorder=3)
    ax.set_ylim(0.0, 1.15)
    ax.set_ylabel("ROC-AUC", fontsize=11, fontweight="bold", color=COLOR_SLATE)
    ax.set_title("Cross-Domain ROC-AUC", fontsize=13, fontweight="bold", color=COLOR_TITLE, pad=12)
    ax.grid(axis="y", linestyle="--", alpha=0.5, color=COLOR_GRID, zorder=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    
    # Values above bars
    ax.text(0, 0.4630 + 0.03, "0.4630", ha="center", va="bottom", fontsize=11, fontweight="bold", color=COLOR_RED)
    ax.text(1, 0.9920 + 0.03, "0.992", ha="center", va="bottom", fontsize=11, fontweight="bold", color=COLOR_BLUE)

    plt.tight_layout()
    path = OUTPUT_DIR / "asset_2_cross_domain_roc_auc.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Asset 2: {path}")


# -----------------------------------------------------------------------------
# ASSET 3: ADAPTED ROC-AUC WITH CONFIDENCE INTERVAL
# -----------------------------------------------------------------------------
def generate_asset_3():
    fig, ax = plt.subplots(figsize=(6.5, 3.8), dpi=300, facecolor=COLOR_BG)
    ax.set_facecolor(COLOR_BG)
    
    y = [0]
    x = [0.992]
    xerr_lower = 0.992 - 0.989
    xerr_upper = 0.996 - 0.992
    
    ax.errorbar(x, y, xerr=[[xerr_lower], [xerr_upper]], fmt="o", color=COLOR_BLUE, ecolor=COLOR_TITLE,
                capsize=8, capthick=2, ms=9, zorder=3)
    
    ax.set_xlim(0.980, 1.000)
    ax.set_yticks([])
    ax.set_xlabel("ROC-AUC", fontsize=11, fontweight="bold", color=COLOR_SLATE)
    ax.set_title("5% Target-Domain Adaptation — ROC-AUC with 95% CI", fontsize=12, fontweight="bold", color=COLOR_TITLE, pad=12)
    ax.grid(axis="x", linestyle="--", alpha=0.5, color=COLOR_GRID, zorder=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    
    # Point labels
    ax.text(0.989, 0.08, "0.989\n(Lower CI)", ha="center", va="bottom", fontsize=9.5, fontweight="bold", color=COLOR_SLATE)
    ax.text(0.992, -0.15, "0.992\n(Point Estimate)", ha="center", va="top", fontsize=10, fontweight="bold", color=COLOR_BLUE)
    ax.text(0.996, 0.08, "0.996\n(Upper CI)", ha="center", va="bottom", fontsize=9.5, fontweight="bold", color=COLOR_SLATE)

    plt.tight_layout()
    path = OUTPUT_DIR / "asset_3_adapted_roc_auc_ci.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Asset 3: {path}")


# -----------------------------------------------------------------------------
# ASSET 4: STATISTICAL SIGNIFICANCE TABLE
# -----------------------------------------------------------------------------
def generate_asset_4():
    fig, ax = plt.subplots(figsize=(5.5, 2.5), dpi=300, facecolor=COLOR_BG)
    ax.axis("off")
    
    table_data = [
        ["Statistical Measure", "Result"],
        ["Cohen’s dz", "1.134"],
        ["p-value", "0.0024"],
        ["95% CI", "[0.989, 0.996]"]
    ]
    
    table = ax.table(cellText=table_data, loc="center", cellLoc="center")
    table.scale(1, 1.8)
    
    # Table styling
    for (r, c), cell in table.get_celld().items():
        cell.set_edgecolor("#CBD5E1")
        cell.set_linewidth(1)
        if r == 0:
            cell.set_facecolor(COLOR_HEADER_BG)
            cell.get_text().set_fontweight("bold")
            cell.get_text().set_color(COLOR_TITLE)
            cell.get_text().set_fontsize(10.5)
        else:
            if r % 2 == 1:
                cell.set_facecolor(COLOR_BG)
            else:
                cell.set_facecolor(COLOR_ALT_ROW)
            cell.get_text().set_fontsize(10)
            cell.get_text().set_color(COLOR_TITLE)
            if c == 1:
                cell.get_text().set_fontweight("bold")

    ax.set_title("Statistical Evidence", fontsize=12, fontweight="bold", color=COLOR_TITLE, pad=10)
    plt.tight_layout()
    path = OUTPUT_DIR / "asset_4_statistical_evidence_table.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Asset 4: {path}")


# -----------------------------------------------------------------------------
# ASSET 5: SHORTCUT ABLATION VISUAL
# -----------------------------------------------------------------------------
def generate_asset_5():
    fig, ax = plt.subplots(figsize=(6.5, 2.8), dpi=300, facecolor=COLOR_BG)
    ax.set_facecolor(COLOR_BG)
    
    y = [0]
    width = [97.2]
    
    ax.barh(y, width, height=0.4, color=COLOR_GREEN, edgecolor=COLOR_TITLE, linewidth=1.2, zorder=3)
    ax.set_xlim(0, 115)
    ax.set_yticks([])
    ax.set_xlabel("Retention Percentage (%)", fontsize=10, fontweight="bold", color=COLOR_SLATE)
    ax.set_title("Shortcut Ablation — Performance Retention", fontsize=12, fontweight="bold", color=COLOR_TITLE, pad=12)
    ax.grid(axis="x", linestyle="--", alpha=0.5, color=COLOR_GRID, zorder=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    
    # Label inside / at end of bar
    ax.text(97.2 + 2, 0, "97.2%", va="center", ha="left", fontsize=12, fontweight="bold", color=COLOR_GREEN)

    plt.tight_layout()
    path = OUTPUT_DIR / "asset_5_shortcut_ablation.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Asset 5: {path}")


# -----------------------------------------------------------------------------
# ASSET 6: COMPLETE PERFORMANCE SUMMARY TABLE
# -----------------------------------------------------------------------------
def generate_asset_6():
    fig, ax = plt.subplots(figsize=(7.5, 4.5), dpi=300, facecolor=COLOR_BG)
    ax.axis("off")
    
    table_data = [
        ["Evaluation", "Metric", "Result"],
        ["Within-Domain", "Macro F1", "0.986"],
        ["Within-Domain", "False Positive Rate", "1.6%"],
        ["Cross-Domain Zero-Shot", "ROC-AUC", "0.4630"],
        ["Cross-Domain — 5% Adaptation", "ROC-AUC", "0.992"],
        ["5% Adaptation", "95% CI", "[0.989, 0.996]"],
        ["Statistical Analysis", "Cohen’s dz", "1.134"],
        ["Statistical Analysis", "p-value", "0.0024"],
        ["Shortcut Ablation", "Performance Retention", "97.2%"]
    ]
    
    table = ax.table(cellText=table_data, loc="center", cellLoc="left")
    table.scale(1, 1.6)
    
    for (r, c), cell in table.get_celld().items():
        cell.set_edgecolor("#CBD5E1")
        cell.set_linewidth(1)
        if r == 0:
            cell.set_facecolor(COLOR_HEADER_BG)
            cell.get_text().set_fontweight("bold")
            cell.get_text().set_color(COLOR_TITLE)
            cell.get_text().set_fontsize(10.5)
        else:
            if r % 2 == 1:
                cell.set_facecolor(COLOR_BG)
            else:
                cell.set_facecolor(COLOR_ALT_ROW)
            cell.get_text().set_fontsize(9.5)
            cell.get_text().set_color(COLOR_TITLE)
            if c == 2:
                cell.get_text().set_fontweight("bold")

    ax.set_title("Master Performance Evaluation Summary", fontsize=13, fontweight="bold", color=COLOR_TITLE, pad=12)
    plt.tight_layout()
    path = OUTPUT_DIR / "asset_6_master_performance_summary_table.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Asset 6: {path}")


# -----------------------------------------------------------------------------
# ASSET 7: OPERATIONAL PERFORMANCE TABLE
# -----------------------------------------------------------------------------
def generate_asset_7():
    fig, ax = plt.subplots(figsize=(6.5, 4.8), dpi=300, facecolor=COLOR_BG)
    ax.axis("off")
    
    table_data = [
        ["Runtime Metric", "Result"],
        ["System Health", "HEALTHY"],
        ["Packets Processed", "4"],
        ["Flows Completed", "2"],
        ["Alerts Emitted", "1"],
        ["Errors Encountered", "0"],
        ["Mean Latency", "31.011 ms/flow"],
        ["P95 Latency", "31.092 ms/flow"],
        ["Calibrated Threshold", "0.71"],
        ["Automated Tests", "71/71 PASS"],
        ["Warnings", "0"]
    ]
    
    table = ax.table(cellText=table_data, loc="center", cellLoc="left")
    table.scale(1, 1.5)
    
    for (r, c), cell in table.get_celld().items():
        cell.set_edgecolor("#CBD5E1")
        cell.set_linewidth(1)
        if r == 0:
            cell.set_facecolor(COLOR_HEADER_BG)
            cell.get_text().set_fontweight("bold")
            cell.get_text().set_color(COLOR_TITLE)
            cell.get_text().set_fontsize(10.5)
        else:
            if r % 2 == 1:
                cell.set_facecolor(COLOR_BG)
            else:
                cell.set_facecolor(COLOR_ALT_ROW)
            cell.get_text().set_fontsize(9.5)
            cell.get_text().set_color(COLOR_TITLE)
            if c == 1:
                cell.get_text().set_fontweight("bold")
                if table_data[r][1] in ["HEALTHY", "71/71 PASS", "0"]:
                    cell.get_text().set_color(COLOR_GREEN)
                elif table_data[r][1] == "1":
                    cell.get_text().set_color(COLOR_RED)

    ax.set_title("Operational Validation Metrics", fontsize=13, fontweight="bold", color=COLOR_TITLE, pad=12)
    plt.tight_layout()
    path = OUTPUT_DIR / "asset_7_operational_metrics_table.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Asset 7: {path}")


# -----------------------------------------------------------------------------
# ASSET 8: OPERATIONAL METRIC DASHBOARD
# -----------------------------------------------------------------------------
def generate_asset_8():
    fig, ax = plt.subplots(figsize=(8.5, 4.2), dpi=300, facecolor=COLOR_BG)
    ax.axis("off")
    
    ax.text(0.02, 0.92, "Operational Edge Metric Dashboard", fontsize=13, fontweight="bold", color=COLOR_TITLE)
    
    cards = [
        ("System Health", "HEALTHY", "#16A34A", "#F0FDF4", "#86EFAC"),
        ("Packets Processed", "4", "#0F172A", "#FFFFFF", "#CBD5E1"),
        ("Flows Completed", "2", "#0F172A", "#FFFFFF", "#CBD5E1"),
        ("Alerts Emitted", "1", "#DC2626", "#FEF2F2", "#FCA5A5"),
        ("Errors Encountered", "0", "#16A34A", "#F0FDF4", "#86EFAC"),
        ("Mean Latency", "31.011 ms", "#334155", "#FFFFFF", "#CBD5E1"),
        ("P95 Latency", "31.092 ms", "#334155", "#FFFFFF", "#CBD5E1"),
        ("Automated Pytests", "71/71 PASS", "#16A34A", "#F0FDF4", "#86EFAC"),
    ]
    
    # 2 rows, 4 columns
    cols = 4
    rows = 2
    w = 0.22
    h = 0.34
    
    for idx, (label, val, txt_col, bg_col, border_col) in enumerate(cards):
        r = idx // cols
        c = idx % cols
        x = 0.02 + c * 0.245
        y = 0.48 - r * 0.42
        
        rect = patches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02", ec=border_col, fc=bg_col, lw=1.2)
        ax.add_patch(rect)
        
        ax.text(x + 0.02, y + 0.24, label.upper(), fontsize=8, fontweight="bold", color=COLOR_SLATE)
        ax.text(x + 0.02, y + 0.08, val, fontsize=13, fontweight="bold", color=txt_col)
        
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)

    plt.tight_layout()
    path = OUTPUT_DIR / "asset_8_operational_metric_dashboard.png"
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Asset 8: {path}")


if __name__ == "__main__":
    generate_asset_1()
    generate_asset_2()
    generate_asset_3()
    generate_asset_4()
    generate_asset_5()
    generate_asset_6()
    generate_asset_7()
    generate_asset_8()
    print("All 8 individual assets generated successfully in PPT/assets/!")
