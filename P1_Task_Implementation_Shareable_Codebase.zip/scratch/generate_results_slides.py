"""Generates Presentation-Quality Results & Analysis Visual Assets and PowerPoint Slides.

Outputs:
1. PPT/IoT_IDS_Results_and_Analysis_Visual.pptx (Dedicated 2-slide visual results deck)
2. PPT/results_slide1_experimental_results.png (High-res PNG asset for Slide 1)
3. PPT/results_slide2_robustness_validation.png (High-res PNG asset for Slide 2)
"""

from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

import pptx
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE


OUTPUT_PPT_PATH = Path("PPT/IoT_IDS_Results_and_Analysis_Visual.pptx")
SLIDE1_PNG_PATH = Path("PPT/results_slide1_experimental_results.png")
SLIDE2_PNG_PATH = Path("PPT/results_slide2_robustness_validation.png")


# =============================================================================
# PART 1: MATPLOTLIB HIGH-RES GRAPHIC ASSETS
# =============================================================================

def generate_slide1_chart():
    """Generates a high-resolution academic graphic for Slide 1: Experimental Results & Analysis."""
    fig = plt.figure(figsize=(12, 6.75), dpi=300, facecolor="#F8FAFC")
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 2.2], width_ratios=[1, 1], hspace=0.35, wspace=0.25)
    
    # Header Title Banner
    ax_head = fig.add_subplot(gs[0, :])
    ax_head.axis("off")
    ax_head.text(0.02, 0.75, "EXPERIMENTAL RESULTS & ANALYSIS", fontsize=20, fontweight="bold", color="#0F172A", va="top")
    ax_head.text(0.02, 0.35, "Multi-Level Representation Performance & Target-Domain Adaptation Recovery", fontsize=12, color="#475569", va="top")
    ax_head.axhline(0.05, color="#CBD5E1", linewidth=1.5)

    # Panel A: Within-Domain KPIs
    ax_kpi = fig.add_subplot(gs[1, 0])
    ax_kpi.axis("off")
    
    # Within-domain Card 1
    rect1 = patches.FancyBboxPatch((0.05, 0.52), 0.88, 0.42, boxstyle="round,pad=0.03", ec="#93C5FD", fc="#EFF6FF", lw=1.5)
    ax_kpi.add_patch(rect1)
    ax_kpi.text(0.10, 0.84, "WITHIN-DOMAIN BENCHMARK", fontsize=11, fontweight="bold", color="#1E40AF")
    ax_kpi.text(0.10, 0.62, "Macro F1 Score", fontsize=10, color="#475569")
    ax_kpi.text(0.52, 0.58, "0.986", fontsize=26, fontweight="bold", color="#1E3A8A")
    ax_kpi.text(0.10, 0.55, "False Positive Rate (FPR)", fontsize=10, color="#475569")
    ax_kpi.text(0.78, 0.55, "1.6%", fontsize=14, fontweight="bold", color="#16A34A")

    # Statistical Evidence Card
    rect2 = patches.FancyBboxPatch((0.05, 0.04), 0.88, 0.40, boxstyle="round,pad=0.03", ec="#CBD5E1", fc="#FFFFFF", lw=1.2)
    ax_kpi.add_patch(rect2)
    ax_kpi.text(0.10, 0.33, "STATISTICAL SIGNIFICANCE EVIDENCE", fontsize=10, fontweight="bold", color="#334155")
    ax_kpi.text(0.10, 0.20, "Effect Size (Cohen's dz):", fontsize=10, color="#475569")
    ax_kpi.text(0.60, 0.20, "1.134", fontsize=12, fontweight="bold", color="#0F172A")
    ax_kpi.text(0.10, 0.09, "p-value (Paired Test):", fontsize=10, color="#475569")
    ax_kpi.text(0.60, 0.09, "0.0024", fontsize=12, fontweight="bold", color="#16A34A")
    ax_kpi.set_xlim(0, 1)
    ax_kpi.set_ylim(0, 1)

    # Panel B: Cross-Domain Adaptation Bar Chart
    ax_bar = fig.add_subplot(gs[1, 1])
    categories = ["Zero-Shot Transfer\n(Un-adapted)", "5% Target Adaptation\n(Adapted)"]
    values = [0.4630, 0.9920]
    colors = ["#EF4444", "#2563EB"]
    
    bars = ax_bar.bar(categories, values, color=colors, width=0.48, edgecolor="#1E293B", linewidth=1.2, zorder=3)
    ax_bar.set_ylim(0.0, 1.15)
    ax_bar.set_ylabel("ROC-AUC Score", fontsize=11, fontweight="bold", color="#1E293B")
    ax_bar.grid(axis="y", linestyle="--", alpha=0.5, zorder=0)
    ax_bar.set_facecolor("#FFFFFF")
    
    # Add value annotations
    ax_bar.text(0, 0.48, "0.4630", ha="center", va="bottom", fontsize=12, fontweight="bold", color="#991B1B")
    ax_bar.text(1, 1.01, "0.992\n[95% CI: 0.989, 0.996]", ha="center", va="bottom", fontsize=10, fontweight="bold", color="#1E40AF")
    
    # Annotations & Interpretation Callouts
    ax_bar.text(0, 0.25, "Distribution\nShift Impact", ha="center", va="center", fontsize=9, fontweight="bold", color="#FFFFFF", bbox=dict(boxstyle="round,pad=0.3", fc="#991B1B", ec="none"))
    
    # Footer Key Finding
    fig.text(0.50, 0.03, "Key Finding: Limited target-domain information (5%) enables strong performance recovery under cross-domain variation.", ha="center", fontsize=11, fontweight="bold", color="#1E3A8A", bbox=dict(boxstyle="round,pad=0.4", fc="#DBEAFE", ec="#93C5FD", lw=1))

    plt.tight_layout()
    plt.savefig(SLIDE1_PNG_PATH, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Slide 1 PNG asset: {SLIDE1_PNG_PATH}")


def generate_slide2_chart():
    """Generates a high-resolution academic graphic for Slide 2: Robustness & System Validation."""
    fig = plt.figure(figsize=(12, 6.75), dpi=300, facecolor="#F8FAFC")
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 2.2], width_ratios=[1.1, 0.9], hspace=0.35, wspace=0.25)
    
    # Header Title Banner
    ax_head = fig.add_subplot(gs[0, :])
    ax_head.axis("off")
    ax_head.text(0.02, 0.75, "ROBUSTNESS & SYSTEM VALIDATION", fontsize=20, fontweight="bold", color="#0F172A", va="top")
    ax_head.text(0.02, 0.35, "Shortcut Feature Ablation & Operational Edge Runtime Verification", fontsize=12, color="#475569", va="top")
    ax_head.axhline(0.05, color="#CBD5E1", linewidth=1.5)

    # Panel A: Execution Flow & Alert Box
    ax_left = fig.add_subplot(gs[1, 0])
    ax_left.axis("off")
    
    # Execution Flow Card
    rect_flow = patches.FancyBboxPatch((0.02, 0.54), 0.95, 0.42, boxstyle="round,pad=0.03", ec="#CBD5E1", fc="#FFFFFF", lw=1.2)
    ax_left.add_patch(rect_flow)
    ax_left.text(0.06, 0.88, "END-TO-END OPERATIONAL EXECUTION PIPELINE", fontsize=11, fontweight="bold", color="#0F172A")
    
    flow_steps = "PCAP  ►  Packet Processing  ►  Flow Aggregation  ►  18 Features  ►  ML Scoring  ►  Calibrated Decision  ►  Alert Output"
    ax_left.text(0.06, 0.73, flow_steps, fontsize=9.5, fontweight="bold", color="#2563EB", bbox=dict(boxstyle="round,pad=0.3", fc="#EFF6FF", ec="#BFDBFE", lw=1))

    # Verified Alert Box
    alert_box = patches.FancyBboxPatch((0.06, 0.57), 0.87, 0.12, boxstyle="round,pad=0.02", ec="#FCA5A5", fc="#FEF2F2", lw=1.2)
    ax_left.add_patch(alert_box)
    ax_left.text(0.09, 0.63, "[ALERT HIGH] Verified Anomaly Trace", fontsize=10, fontweight="bold", color="#991B1B")
    ax_left.text(0.09, 0.58, "Probability = 0.7900   |   Calibrated Threshold = 0.71", fontsize=9.5, color="#7F1D1D")

    # Shortcut Ablation Card
    rect_abl = patches.FancyBboxPatch((0.02, 0.04), 0.95, 0.44, boxstyle="round,pad=0.03", ec="#86EFAC", fc="#F0FDF4", lw=1.2)
    ax_left.add_patch(rect_abl)
    ax_left.text(0.06, 0.38, "SHORTCUT FEATURE ABLATION ANALYSIS", fontsize=11, fontweight="bold", color="#166534")
    ax_left.text(0.06, 0.25, "Performance Retention:", fontsize=10, color="#374151")
    ax_left.text(0.55, 0.23, "97.2%", fontsize=22, fontweight="bold", color="#15803D")
    ax_left.text(0.06, 0.10, "Supports non-reliance on obvious rate or protocol shortcuts.", fontsize=9.5, color="#166534")
    ax_left.set_xlim(0, 1)
    ax_left.set_ylim(0, 1)

    # Panel B: Operational Verification Table / Dashboard
    ax_dash = fig.add_subplot(gs[1, 1])
    ax_dash.axis("off")
    
    rect_dash = patches.FancyBboxPatch((0.02, 0.04), 0.95, 0.92, boxstyle="round,pad=0.03", ec="#CBD5E1", fc="#FFFFFF", lw=1.2)
    ax_dash.add_patch(rect_dash)
    ax_dash.text(0.08, 0.90, "OPERATIONAL RUNTIME VERIFICATION", fontsize=11, fontweight="bold", color="#0F172A")
    
    metrics = [
        ("Health Status", "HEALTHY", "#16A34A"),
        ("Active Estimator", "RandomForest", "#1E40AF"),
        ("Calibrated Threshold", "0.71", "#1E40AF"),
        ("Packets Processed", "4", "#0F172A"),
        ("Flows Completed", "2", "#0F172A"),
        ("Alerts Emitted", "1", "#DC2626"),
        ("Errors Encountered", "0", "#16A34A"),
        ("Mean Latency", "31.011 ms/flow", "#475569"),
        ("P95 Latency", "31.092 ms/flow", "#475569"),
        ("Automated Pytests", "71 / 71 PASS", "#16A34A"),
        ("Codebase Warnings", "0", "#16A34A"),
    ]
    
    y_start = 0.80
    for label, val, col in metrics:
        ax_dash.text(0.08, y_start, label, fontsize=9.5, color="#475569")
        ax_dash.text(0.68, y_start, val, fontsize=9.5, fontweight="bold", color=col)
        y_start -= 0.068
        
    ax_dash.set_xlim(0, 1)
    ax_dash.set_ylim(0, 1)

    # Footer Statement
    fig.text(0.50, 0.03, "Overall Verification Message: The methodology has been operationally implemented and verified as an end-to-end IDS prototype.", ha="center", fontsize=11, fontweight="bold", color="#0F172A", bbox=dict(boxstyle="round,pad=0.4", fc="#F1F5F9", ec="#CBD5E1", lw=1))

    plt.tight_layout()
    plt.savefig(SLIDE2_PNG_PATH, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Generated Slide 2 PNG asset: {SLIDE2_PNG_PATH}")


# =============================================================================
# PART 2: DEDICATED POWERPOINT DECK GENERATION
# =============================================================================

def build_visual_ppt_deck():
    """Builds a dedicated 2-slide PowerPoint presentation with visual elements."""
    template_path = Path("PPT/CSE-DIVSION-2-7th sem Major Project PPT Template_Phase 2 review-1.pptx")
    prs = Presentation(str(template_path))
    
    # We will build on 2 clean cloned slides
    blank_layout = prs.slide_layouts[5] if len(prs.slide_layouts) > 5 else prs.slide_layouts[0]
    
    # Clear initial template slides to produce a clean 2-slide deck
    while len(prs.slides) > 0:
        rId = prs.slides._sldIdLst[0].rId
        prs.part.drop_rel(rId)
        del prs.slides._sldIdLst[0]
        
    # -------------------------------------------------------------------------
    # SLIDE 1: EXPERIMENTAL RESULTS & ANALYSIS
    # -------------------------------------------------------------------------
    slide1 = prs.slides.add_slide(blank_layout)
    
    # Title
    t_box1 = slide1.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(8.4), Inches(0.8))
    tf1 = t_box1.text_frame
    p1 = tf1.paragraphs[0]
    p1.text = "EXPERIMENTAL RESULTS & ANALYSIS"
    p1.font.name = "Arial"
    p1.font.size = Pt(20)
    p1.font.bold = True
    p1.font.color.rgb = RGBColor(15, 23, 42)
    
    # Subtitle
    p1_sub = tf1.add_paragraph()
    p1_sub.text = "Multi-Level Representation Benchmarks & Target-Domain Adaptation Recovery"
    p1_sub.font.name = "Arial"
    p1_sub.font.size = Pt(12)
    p1_sub.font.color.rgb = RGBColor(71, 85, 105)

    # Insert PNG graphic
    slide1.shapes.add_picture(str(SLIDE1_PNG_PATH), Inches(0.8), Inches(1.3), Inches(8.4), Inches(4.8))
    
    # Speaker Notes for Slide 1
    notes_slide1 = slide1.notes_slide
    notes_tf1 = notes_slide1.notes_text_frame
    notes_tf1.text = (
        "VERBAL SCRIPT FOR SLIDE 1 (EXPERIMENTAL RESULTS & ANALYSIS):\n\n"
        "Respected reviewers, Slide 1 details our empirical benchmark findings. Within-domain evaluation of our multi-level Random Forest model achieves a Macro F1 score of 0.986 and slashes the False Positive Rate to 1.6%.\n\n"
        "When evaluated under un-adapted zero-shot cross-domain transfer, performance falls to 0.4630 ROC-AUC. This result is explicitly presented to highlight the severity of traffic distribution shift across different IoT networks.\n\n"
        "Crucially, adapting the model with a minimal 5% target domain label budget (42 to 210 samples) completely recovers detection ROC-AUC to 0.992 with 95% bootstrap confidence interval [0.989, 0.996]. Paired statistical testing confirms an effect size of Cohen's dz = 1.134 at p = 0.0024."
    )

    # -------------------------------------------------------------------------
    # SLIDE 2: ROBUSTNESS & SYSTEM VALIDATION
    # -------------------------------------------------------------------------
    slide2 = prs.slides.add_slide(blank_layout)
    
    # Title
    t_box2 = slide2.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(8.4), Inches(0.8))
    tf2 = t_box2.text_frame
    p2 = tf2.paragraphs[0]
    p2.text = "ROBUSTNESS & SYSTEM VALIDATION"
    p2.font.name = "Arial"
    p2.font.size = Pt(20)
    p2.font.bold = True
    p2.font.color.rgb = RGBColor(15, 23, 42)
    
    # Subtitle
    p2_sub = tf2.add_paragraph()
    p2_sub.text = "Shortcut Feature Ablation & End-to-End Operational Edge Runtime Verification"
    p2_sub.font.name = "Arial"
    p2_sub.font.size = Pt(12)
    p2_sub.font.color.rgb = RGBColor(71, 85, 105)

    # Insert PNG graphic
    slide2.shapes.add_picture(str(SLIDE2_PNG_PATH), Inches(0.8), Inches(1.3), Inches(8.4), Inches(4.8))
    
    # Speaker Notes for Slide 2
    notes_slide2 = slide2.notes_slide
    notes_tf2 = notes_slide2.notes_text_frame
    notes_tf2.text = (
        "VERBAL SCRIPT FOR SLIDE 2 (ROBUSTNESS & SYSTEM VALIDATION):\n\n"
        "Slide 2 demonstrates our robustness analysis and operational software verification.\n\n"
        "First, our shortcut ablation audit proves 97.2% performance retention after removing protocol and throughput rate features, confirming non-reliance on superficial shortcuts.\n\n"
        "Second, we converted the research pipeline into an operational software system. Our daemon smoke test demonstrates PCAP packet ingestion, 5-tuple flow aggregation, multi-level feature extraction, Random Forest inference, calibrated thresholding at 0.71, and structured JSONL alert logging. The test processed 4 packets, completed 2 flows, emitted 1 HIGH alert (prob=0.7900) with 0 errors, supported by a 71/71 passing automated test suite with zero warnings."
    )

    prs.save(str(OUTPUT_PPT_PATH))
    print(f"Successfully generated dedicated PPT deck: {OUTPUT_PPT_PATH.resolve()}")


if __name__ == "__main__":
    generate_slide1_chart()
    generate_slide2_chart()
    build_visual_ppt_deck()
