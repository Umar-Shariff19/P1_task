import os
import json

extracts = json.load(open('paper_support/literature_extracts.json'))
print(f"Total extracts in json: {len(extracts)}")
for idx, entry in enumerate(extracts, 1):
    fname = entry.get('filename') or entry.get('file')
    chars = entry.get('first_1500_chars', '')
    print(f"[{idx}] FILENAME: {fname}")
    print(chars[:600])
    print("=" * 60)
