"""Level 2 Forensic Discrepancy-Resolution Investigation Script.

Investigates:
CASE 1 — Option C Ensemble (Standard MLP vs Robust MLP Ensemble)
CASE 2 — Adversarial PGD Attack Pipeline (Normalized vs Scaled Feature Perturbations, Epsilon Scale, ASR Definitions)
CASE 3 — CICIoT2023 Robust MLP Contradiction (0.00% vs 0.20% vs 0.80%)
CASE 4 — ToN-IoT Adversarial Discrepancy (0.00% vs 1.80%)
"""
import hashlib
import json
import os
import sys
from pathlib import Path

REPO_ROOT = Path(r"C:\Users\umari\Documents\P1_task_Implementation")
sys.path.insert(0, str(REPO_ROOT / "src"))

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score

DATASETS = ["ToN-IoT", "Edge-IIoTset", "NF-ToN-IoT-v2", "CICIoT2023"]

# --- PyTorch MLP Architecture ---
class MLPModule(nn.Module):
    def __init__(self, input_dim: int = 21):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

def investigate_case_1_ensemble():
    print("=" * 70)
    print("=== CASE 1 FORENSIC INVESTIGATION: OPTION C ENSEMBLE ===")
    print("=" * 70)

    historical_json = json.loads((REPO_ROOT / "reports" / "standardized" / "standardized_ensemble_results.json").read_text(encoding="utf-8"))

    case1_report = {}
    for ds in DATASETS:
        model_dir = REPO_ROOT / "models" / "standardized" / ds
        test_path = REPO_ROOT / "data" / "processed" / "stage3" / ds / "test.parquet"

        df_test = pd.read_parquet(test_path)
        y_test = df_test["label"].to_numpy()

        feat_cols = [
            "flow_duration", "flow_bytes_per_sec", "flow_pkts_per_sec", "mean_pkt_size",
            "payload_byte_ratio", "pkt_count_ratio", "tcp_syn_ratio", "proto_tcp",
            "proto_udp", "proto_icmp", "proto_other", "temporal_iat_mean", "temporal_iat_cv",
            "temporal_flow_rate_ewma", "temporal_byte_rate_ewma", "temporal_syn_rate_ewma",
            "behavioral_dst_diversity", "behavioral_port_entropy", "behavioral_fanout_ratio",
            "behavioral_unanswered_ratio", "behavioral_src_activity_ewma"
        ]

        prep = joblib.load(model_dir / "prep_standardized.joblib")
        rf = joblib.load(model_dir / "rf_model.joblib")
        X_proc = prep.transform(df_test[feat_cols])

        # RF Probs
        p_rf = rf.predict_proba(X_proc)[:, 1]

        # Standard MLP Probs (mlp_model.pt)
        mlp_std = MLPModule(input_dim=21)
        mlp_std.load_state_dict(torch.load(model_dir / "mlp_model.pt", weights_only=True))
        mlp_std.eval()
        with torch.no_grad():
            std_logits = mlp_std(torch.tensor(X_proc, dtype=torch.float32)).squeeze(-1)
            p_mlp_std = torch.sigmoid(std_logits).numpy()

        # Robust MLP Probs (mlp_adversarial.pt)
        mlp_adv = MLPModule(input_dim=21)
        mlp_adv.load_state_dict(torch.load(model_dir / "mlp_adversarial.pt", weights_only=True))
        mlp_adv.eval()
        with torch.no_grad():
            adv_logits = mlp_adv(torch.tensor(X_proc, dtype=torch.float32)).squeeze(-1)
            p_mlp_adv = torch.sigmoid(adv_logits).numpy()

        # Compute ensembles
        # 1. Ensemble with Standard MLP (alpha=0.7)
        p_ens_std_07 = 0.7 * p_rf + 0.3 * p_mlp_std
        auc_std_07 = roc_auc_score(y_test, p_ens_std_07)

        # 2. Option C Ensemble with Robust MLP (0.7 * RF + 0.3 * Robust MLP)
        p_opt_c = 0.7 * p_rf + 0.3 * p_mlp_adv
        auc_opt_c = roc_auc_score(y_test, p_opt_c)

        hist_alpha_07 = historical_json[ds]["ensemble_rf_mlp"]["alpha_0.7"]["auc"]
        diff_std = abs(auc_std_07 - hist_alpha_07)

        case1_report[ds] = {
            "historical_artifact_alpha_0.7": hist_alpha_07,
            "reproduced_standard_ensemble_alpha_0.7": float(auc_std_07),
            "reproduced_option_c_robust_ensemble": float(auc_opt_c),
            "exact_match_to_historical_std_ensemble": diff_std < 1e-6,
            "diff_from_historical": float(diff_std),
        }

        print(f"[{ds}]")
        print(f"  Historical JSON alpha_0.7 AUC:            {hist_alpha_07:.6f}")
        print(f"  Reproduced Standard Ensemble (alpha=0.7): {auc_std_07:.6f}  (Diff: {diff_std:.8f})")
        print(f"  Option C (RF + Robust MLP) Ensemble AUC:   {auc_opt_c:.6f}")

    # Means and variances
    hist_aucs = [case1_report[ds]["historical_artifact_alpha_0.7"] for ds in DATASETS]
    std_aucs = [case1_report[ds]["reproduced_standard_ensemble_alpha_0.7"] for ds in DATASETS]
    opt_c_aucs = [case1_report[ds]["reproduced_option_c_robust_ensemble"] for ds in DATASETS]

    print("\n--- Summary Comparison ---")
    print(f"Historical Standard Ensemble Mean AUC: {np.mean(hist_aucs):.6f}, Var: {np.var(hist_aucs):.8f}")
    print(f"Reproduced Standard Ensemble Mean AUC: {np.mean(std_aucs):.6f}, Var: {np.var(std_aucs):.8f}")
    print(f"Option C (Robust MLP) Ensemble Mean AUC: {np.mean(opt_c_aucs):.6f}, Var: {np.var(opt_c_aucs):.8f}")

    return case1_report

def investigate_cases_2_3_4_adversarial():
    print("\n" + "=" * 70)
    print("=== CASES 2, 3, 4 FORENSIC INVESTIGATION: ADVERSARIAL PGD ATTACKS ===")
    print("=" * 70)

    from iot_ids.adversarial.attacks import pgd_attack

    std_adv_path = REPO_ROOT / "reports" / "standardized" / "adversarial" / "adversarial_results.json"
    std_adv_json = json.loads(std_adv_path.read_text(encoding="utf-8")) if std_adv_path.exists() else {}

    print("\n--- Stored JSON Artifacts in reports/standardized/adversarial/adversarial_results.json ---")
    for ds in DATASETS:
        if ds in std_adv_json:
            std_list = std_adv_json[ds].get("standard_mlp", [])
            adv_list = std_adv_json[ds].get("adversarial_mlp", [])

            std_pgd = [x for x in std_list if isinstance(x, dict) and x.get("attack") == "PGD" and abs(x.get("epsilon", 0) - 0.1) < 0.01]
            adv_pgd = [x for x in adv_list if isinstance(x, dict) and x.get("attack") == "PGD" and abs(x.get("epsilon", 0) - 0.1) < 0.01]

            std_entry = std_pgd[0] if std_pgd else {}
            adv_entry = adv_pgd[0] if adv_pgd else {}

            print(f"\n[{ds}] Stored JSON Artifact (eps=0.10 PGD-10):")
            print(f"  Standard MLP: ASR = {std_entry.get('attack_success_rate'):.6f} ({std_entry.get('attack_success_rate')*100:.2f}%), CleanAcc={std_entry.get('clean_accuracy'):.4f}, AdvAcc={std_entry.get('adv_accuracy'):.4f}, Evaded={std_entry.get('n_evaded')}/{std_entry.get('n_attacked')}")
            print(f"  Robust MLP:   ASR = {adv_entry.get('attack_success_rate'):.6f} ({adv_entry.get('attack_success_rate')*100:.2f}%), CleanAcc={adv_entry.get('clean_accuracy'):.4f}, AdvAcc={adv_entry.get('adv_accuracy'):.4f}, Evaded={adv_entry.get('n_evaded')}/{adv_entry.get('n_attacked')}")

    print("\n--- Deterministic Pipeline Reproduction via pgd_attack() ---")

    eval_report = {}
    for ds in DATASETS:
        model_dir = REPO_ROOT / "models" / "standardized" / ds
        train_path = REPO_ROOT / "data" / "processed" / "stage3" / ds / "train.parquet"
        test_path = REPO_ROOT / "data" / "processed" / "stage3" / ds / "test.parquet"

        train_df = pd.read_parquet(train_path)
        test_df = pd.read_parquet(test_path)

        feat_cols = [
            "flow_duration", "flow_bytes_per_sec", "flow_pkts_per_sec", "mean_pkt_size",
            "payload_byte_ratio", "pkt_count_ratio", "tcp_syn_ratio", "proto_tcp",
            "proto_udp", "proto_icmp", "proto_other", "temporal_iat_mean", "temporal_iat_cv",
            "temporal_flow_rate_ewma", "temporal_byte_rate_ewma", "temporal_syn_rate_ewma",
            "behavioral_dst_diversity", "behavioral_port_entropy", "behavioral_fanout_ratio",
            "behavioral_unanswered_ratio", "behavioral_src_activity_ewma"
        ]

        prep = joblib.load(model_dir / "prep_standardized.joblib")
        X_train = prep.transform(train_df[feat_cols])
        X_test = prep.transform(test_df[feat_cols])
        y_test = test_df["label"].to_numpy()

        x_min = torch.tensor(X_train.min(axis=0), dtype=torch.float32).unsqueeze(0)
        x_max = torch.tensor(X_train.max(axis=0), dtype=torch.float32).unsqueeze(0)

        discrete_names = {"proto_tcp", "proto_udp", "proto_icmp", "proto_other"}
        cont_mask_list = [0.0 if col in discrete_names else 1.0 for col in feat_cols]
        continuous_mask = torch.tensor(cont_mask_list, dtype=torch.float32).unsqueeze(0)

        eps = 0.10

        models = {
            "standard_mlp": model_dir / "mlp_model.pt",
            "robust_mlp": model_dir / "mlp_adversarial.pt",
        }

        ds_res = {}
        for mname, mpath in models.items():
            model = MLPModule(input_dim=21)
            model.load_state_dict(torch.load(mpath, weights_only=True))
            model.eval()

            X_test_t = torch.tensor(X_test, dtype=torch.float32)
            y_test_t = torch.tensor(y_test, dtype=torch.float32)

            with torch.no_grad():
                clean_logits = model(X_test_t).squeeze(-1)
                clean_probs = torch.sigmoid(clean_logits).numpy()
                clean_preds = (clean_probs >= 0.5).astype(int)
                clean_acc = accuracy_score(y_test, clean_preds)
                clean_auc = roc_auc_score(y_test, clean_probs)

            # Attack execution
            X_adv_t = pgd_attack(model, X_test_t, y_test_t, eps, continuous_mask, x_min, x_max, steps=10)

            with torch.no_grad():
                adv_logits = model(X_adv_t).squeeze(-1)
                adv_probs = torch.sigmoid(adv_logits).numpy()
                adv_preds = (adv_probs >= 0.5).astype(int)
                adv_acc = accuracy_score(y_test, adv_preds)
                adv_auc = roc_auc_score(y_test, adv_probs)

            # Exact historical ASR definition
            attack_mask = (y_test == 1) & (clean_preds == 1)
            n_attacked = int(attack_mask.sum())
            evaded = int((attack_mask & (adv_preds == 0)).sum())
            asr = float(evaded / max(n_attacked, 1))

            ds_res[mname] = {
                "clean_acc": float(clean_acc),
                "clean_auc": float(clean_auc),
                "adv_acc": float(adv_acc),
                "adv_auc": float(adv_auc),
                "n_attacked": n_attacked,
                "n_evaded": evaded,
                "asr": asr,
            }

        eval_report[ds] = ds_res
        print(f"\n[{ds}] Pipeline Reproduction Results:")
        print(f"  Standard MLP: ASR={ds_res['standard_mlp']['asr']:.6f} ({ds_res['standard_mlp']['asr']*100:.2f}%), CleanAcc={ds_res['standard_mlp']['clean_acc']:.4f}, AdvAcc={ds_res['standard_mlp']['adv_acc']:.4f}, Evaded={ds_res['standard_mlp']['n_evaded']}/{ds_res['standard_mlp']['n_attacked']}")
        print(f"  Robust MLP:   ASR={ds_res['robust_mlp']['asr']:.6f} ({ds_res['robust_mlp']['asr']*100:.2f}%), CleanAcc={ds_res['robust_mlp']['clean_acc']:.4f}, AdvAcc={ds_res['robust_mlp']['adv_acc']:.4f}, Evaded={ds_res['robust_mlp']['n_evaded']}/{ds_res['robust_mlp']['n_attacked']}")

    return eval_report

if __name__ == "__main__":
    c1 = investigate_case_1_ensemble()
    c2 = investigate_cases_2_3_4_adversarial()

    out_file = REPO_ROOT / "reports" / "final_verification" / "level2_forensic_run.json"
    out_file.write_text(json.dumps({"case1": c1, "case2_3_4": c2}, indent=2, default=str))
    print(f"\nSaved level2 forensic run to {out_file}")
