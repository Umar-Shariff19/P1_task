import os
import sys
import zipfile
import json
from pathlib import Path

ROOT_DIR = Path(r"c:\Users\umari\Documents\P1_task_Implementation")
OUTPUT_ZIP_PATH = ROOT_DIR / "P1_Task_Implementation_Shareable_Codebase.zip"

EXCLUDE_DIRS = {
    ".git",
    ".venv",
    ".venv-1",
    ".pytest_cache",
    "__pycache__",
    "node_modules",
    ".idea",
    ".vscode"
}

# Subdirectories under data to exclude raw/processed datasets
EXCLUDE_DATA_SUBDIRS = {"raw", "processed", "interim", "cache"}

# File extensions to exclude
EXCLUDE_EXTENSIONS = {
    ".parquet", ".pcap", ".pcapng", ".npy", ".npz", ".h5", ".hdf5",
    ".joblib", ".pt", ".pth", ".pkl", ".bin", ".onnx", ".zip"
}

# Large files (> 1MB) of type CSV or similar data to exclude
LARGE_CSV_THRESHOLD_BYTES = 100 * 1024 # 100 KB for CSVs

included_files = []
excluded_files = []
excluded_large_important = []

for root, dirs, files in os.walk(ROOT_DIR):
    rel_root = Path(root).relative_to(ROOT_DIR)

    # Filter out excluded directories in-place
    dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not (d == "__pycache__")]
    
    # Check if we are inside data/raw, data/processed, etc.
    parts = rel_root.parts
    if len(parts) >= 2 and parts[0] == "data" and parts[1] in EXCLUDE_DATA_SUBDIRS:
        for f in files:
            file_path = rel_root / f
            abs_path = ROOT_DIR / file_path
            size = abs_path.stat().st_size
            excluded_files.append({"path": str(file_path), "size": size, "reason": "Dataset file in data/" + parts[1]})
            if size > 10 * 1024:
                excluded_large_important.append({"path": str(file_path), "size": size, "category": "Dataset (" + parts[1] + ")"})
        dirs.clear()
        continue

    for f in files:
        file_path = rel_root / f
        if file_path == Path(OUTPUT_ZIP_PATH.name):
            continue

        abs_path = ROOT_DIR / file_path
        size = abs_path.stat().st_size
        ext = abs_path.suffix.lower()

        # Check exclusion rules
        if ext in EXCLUDE_EXTENSIONS:
            reason = f"Excluded binary/data extension ({ext})"
            excluded_files.append({"path": str(file_path), "size": size, "reason": reason})
            if ext in {".joblib", ".pt", ".pth", ".pkl", ".parquet", ".pcap", ".npy"}:
                cat = "Model Checkpoint" if ext in {".joblib", ".pt", ".pth", ".pkl"} else "Dataset"
                excluded_large_important.append({"path": str(file_path), "size": size, "category": cat})
        elif ext == ".csv" and size > LARGE_CSV_THRESHOLD_BYTES:
            reason = f"Large CSV dataset file ({size / 1024:.1f} KB)"
            excluded_files.append({"path": str(file_path), "size": size, "reason": reason})
            excluded_large_important.append({"path": str(file_path), "size": size, "category": "Large CSV Dataset"})
        else:
            included_files.append({"path": str(file_path), "size": size, "abs_path": abs_path})

print(f"Total files identified to INCLUDE: {len(included_files)}")
print(f"Total files identified to EXCLUDE: {len(excluded_files)}")
print(f"Total important large files EXCLUDED: {len(excluded_large_important)}")

# Build the ZIP
if OUTPUT_ZIP_PATH.exists():
    OUTPUT_ZIP_PATH.unlink()

with zipfile.ZipFile(OUTPUT_ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as zf:
    for item in included_files:
        zf.write(item["abs_path"], arcname=item["path"])

zip_size_bytes = OUTPUT_ZIP_PATH.stat().st_size
print(f"Successfully created ZIP: {OUTPUT_ZIP_PATH}")
print(f"ZIP Size: {zip_size_bytes / (1024*1024):.2f} MB ({zip_size_bytes:,} bytes)")

# Categorize included files
categories = {}
for item in included_files:
    p = item["path"]
    top_dir = p.split(os.sep)[0] if os.sep in p else "Root Files"
    categories[top_dir] = categories.get(top_dir, 0) + 1

summary_data = {
    "zip_name": OUTPUT_ZIP_PATH.name,
    "zip_path": str(OUTPUT_ZIP_PATH),
    "zip_size_mb": round(zip_size_bytes / (1024*1024), 2),
    "zip_size_bytes": zip_size_bytes,
    "total_included_files": len(included_files),
    "included_categories": categories,
    "total_excluded_files": len(excluded_files),
    "important_excluded_files_count": len(excluded_large_important),
    "important_excluded_files": sorted(excluded_large_important, key=lambda x: x["size"], reverse=True)[:50]
}

with open(ROOT_DIR / "reports" / "final_forensic_audit" / "shareable_package_manifest.json", "w") as f:
    json.dump(summary_data, f, indent=2)

print("Saved package manifest to reports/final_forensic_audit/shareable_package_manifest.json")
