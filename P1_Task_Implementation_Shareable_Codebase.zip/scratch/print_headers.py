import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

db = json.load(open('scratch/parsed_25_papers.json', encoding='utf-8'))
for p in db:
    lines = [line.strip() for line in p['sample_text'].split('\n') if line.strip()]
    print(f"[{p['index']}] FILE: {p['filename']}")
    print("HEADER SNIPPET:")
    for line in lines[:12]:
        print("  ", line)
    print("-" * 60)
