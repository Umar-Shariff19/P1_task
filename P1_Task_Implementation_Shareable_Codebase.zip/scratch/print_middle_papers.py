import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

corpus = json.load(open(r"scratch\corpus_25_full.json", encoding="utf-8"))

for p in corpus[2:10]:
    idx = p["index"]
    fname = p["filename"]
    text = p["text_head"]
    
    print(f"[{idx}] {fname}")
    lines = [l.strip() for l in text.split('\n') if l.strip()][:10]
    for line in lines:
        print("   ", line[:120])
    print("-" * 70)
