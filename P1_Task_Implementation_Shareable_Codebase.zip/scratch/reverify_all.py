import sys
import os
import json
import torch
import numpy as np
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT / "src"))

from iot_ids.privacy.dp_sgd import compute_dp_epsilon

def reverify():
    print("=== STARTING FRESH EXPERIMENTAL RE-VERIFICATION ===")
    
    # 1. Inspect Datasets & Splits
    data_dir = REPO_ROOT / "data" / "processed" / "stage3"
    print(f"\n1. Data directory exists: {data_dir.exists()}")
    datasets = ["Edge-IIoTset", "NF-ToN-IoT-v2", "ToN-IoT", "CICIoT2023"]
    for ds in datasets:
        ds_path = data_dir / ds
        if ds_path.exists():
            files = os.listdir(ds_path)
            print(f"   - {ds}: {len(files)} files ({files})")
        else:
            print(f"   - {ds}: Not found in stage3")

    # 2. Inspect Golden Models Checkpoint State
    models_dir = REPO_ROOT / "models" / "golden_run"
    print(f"\n2. Golden Models Checkpoints ({models_dir.exists()}):")
    for ds in datasets:
        ds_models = models_dir / ds
        if ds_models.exists():
            print(f"   - {ds}: {os.listdir(ds_models)}")

    # 3. Privacy DP Accountant Verification
    print("\n3. Verifying Opacus PRV/RDP Accountant Calculation:")
    sample_rate = 64 / 4200 # 0.015238
    steps = 660
    delta = 1e-5
    eps_0_5 = compute_dp_epsilon(steps=steps, sample_rate=sample_rate, noise_multiplier=0.5, target_delta=delta)
    eps_1_0 = compute_dp_epsilon(steps=steps, sample_rate=sample_rate, noise_multiplier=1.0, target_delta=delta)
    eps_2_0 = compute_dp_epsilon(steps=steps, sample_rate=sample_rate, noise_multiplier=2.0, target_delta=delta)
    print(f"   - noise_multiplier=0.5 -> epsilon={eps_0_5:.4f}")
    print(f"   - noise_multiplier=1.0 -> epsilon={eps_1_0:.4f}")
    print(f"   - noise_multiplier=2.0 -> epsilon={eps_2_0:.4f}")

    # 4. Verify Authoritative Golden Manifest Data
    manifest_path = REPO_ROOT / "reports" / "golden_run_manifest.json"
    print(f"\n4. Checking Golden Run Manifest ({manifest_path.exists()}):")
    if manifest_path.exists():
        with open(manifest_path, "r") as f:
            manifest = json.load(f)
        det = manifest.get("detection_summary", {}).get("by_dataset", {})
        for ds, metrics in det.items():
            print(f"   - {ds}: RF={metrics.get('rf_roc_auc'):.4f}, StdMLP={metrics.get('std_mlp_roc_auc'):.4f}, RobMLP={metrics.get('robust_mlp_roc_auc'):.4f}, OptionC={metrics.get('option_c_roc_auc'):.4f}")

    # 5. Verify Runtime Benchmarks Summary
    runtime_path = REPO_ROOT / "reports" / "runtime" / "runtime_overhead_summary.json"
    print(f"\n5. Checking Runtime Benchmark Summary ({runtime_path.exists()}):")
    if runtime_path.exists():
        with open(runtime_path, "r") as f:
            runtime_data = json.load(f)
        b1024 = runtime_data.get("pure_detection_benchmarks", {}).get("1024", {})
        print(f"   - Batch 1024 Latency: {b1024.get('per_sample_latency_ms'):.4f} ms/sample | Throughput: {b1024.get('throughput_samples_per_sec'):.1f} samples/sec")

    print("\n=== RE-VERIFICATION COMPLETE ===")

if __name__ == "__main__":
    reverify()
