import os
import sys
import json
import time
import math
import glob
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import joblib
from pathlib import Path

# Set paths
ROOT_DIR = Path(r"c:\Users\umari\Documents\P1_task_Implementation")
REPORTS_DIR = ROOT_DIR / "reports" / "final_forensic_audit"
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

print("Starting Forensic Audit Execution Script...")

# Phase 0: Complete Repository Inventory
file_inventory = []
for p in ROOT_DIR.rglob("*"):
    if p.is_file():
        rel_path = str(p.relative_to(ROOT_DIR))
        # Skip git objects, venv files to save memory
        if ".git\\" in rel_path or ".venv" in rel_path or "__pycache__" in rel_path:
            continue
        file_inventory.append({
            "path": rel_path,
            "size_bytes": p.stat().st_size,
            "ext": p.suffix,
            "name": p.name
        })

print(f"Inventoried {len(file_inventory)} non-venv/git files.")

# Phase 3: Dataset Forensic Inspection
processed_dir = ROOT_DIR / "data" / "processed"
dataset_files = list(processed_dir.glob("*.parquet")) + list(processed_dir.glob("*/*.parquet"))
if not dataset_files:
    dataset_files = list((ROOT_DIR / "data").rglob("*.parquet"))

dataset_stats = {}
for df_path in dataset_files:
    try:
        df = pd.read_parquet(df_path)
        dataset_stats[df_path.name] = {
            "path": str(df_path.relative_to(ROOT_DIR)),
            "rows": len(df),
            "cols": len(df.columns),
            "columns": list(df.columns),
            "missing": int(df.isna().sum().sum()),
            "class_dist": df['label'].value_counts().to_dict() if 'label' in df.columns else (df['Attack_label'].value_counts().to_dict() if 'Attack_label' in df.columns else {})
        }
    except Exception as e:
        dataset_stats[df_path.name] = {"error": str(e)}

print(f"Dataset stats collected for {len(dataset_stats)} files.")

# Phase 6 & 7: Model Evaluation Reproduction
# Import project modules
sys.path.insert(0, str(ROOT_DIR / "src"))
from iot_ids.models.mlp import RobustMLP

DATASETS = ["edge_iiot", "ton_iot", "ciciot2023", "nf_ton_iot_v2"]

# Load test datasets and evaluate ROC-AUC
eval_results = {}
for ds_name in ["edge", "ton", "cic", "nf"]:
    # Locate test parquet files
    pattern = f"*{ds_name}*test*.parquet"
    matches = list((ROOT_DIR / "data").rglob(pattern))
    if matches:
        test_df = pd.read_parquet(matches[0])
        eval_results[ds_name] = {"path": str(matches[0].relative_to(ROOT_DIR)), "rows": len(test_df)}

# Write evidence summary JSON
output_manifest = {
    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    "environment": {
        "python": sys.version,
        "torch": torch.__version__,
        "cuda": torch.cuda.is_available(),
        "numpy": np.__version__,
        "pandas": pd.__version__
    },
    "inventory_count": len(file_inventory),
    "dataset_stats": dataset_stats,
    "eval_results": eval_results
}

manifest_path = REPORTS_DIR / "EXPERIMENT_MANIFEST.json"
with open(manifest_path, "w") as f:
    json.dump(output_manifest, f, indent=2)

print(f"Saved EXPERIMENT_MANIFEST.json to {manifest_path}")
