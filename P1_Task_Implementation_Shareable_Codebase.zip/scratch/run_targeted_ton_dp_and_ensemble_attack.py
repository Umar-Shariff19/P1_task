"""Targeted DP-SGD Bounded Preprocessing & Ensemble Attack Evaluation Script.

Performs:
  1. Complete ToN-IoT DP-SGD evaluation with bounded preprocessing (RobustScaler -> clip [-10, 10])
     across sigma in {0.0, 0.5, 1.0, 2.0} under Opacus PRV accounting and Poisson sampling.
  2. Tracks exact optimizer steps, sampling rate q, and representative batch-size statistics.
  3. Evaluates ensemble-aware decision attack against fused Option C predictor.
  4. Generates updated privacy evidence summary and final golden manifest.
"""
import sys
import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score

REPO_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(REPO_ROOT / "src"))

from iot_ids.privacy.dp_sgd import DPConfig, compute_dp_epsilon
from iot_ids.adversarial.attacks import pgd_attack

try:
    from opacus.accountants import PRVAccountant, RDPAccountant
    OPACUS_AVAILABLE = True
except ImportError:
    OPACUS_AVAILABLE = False

DATASETS = ["Edge-IIoTset", "NF-ToN-IoT-v2", "ToN-IoT", "CICIoT2023"]
STAGE3_DIR = REPO_ROOT / "data" / "processed" / "stage3"
MODELS_DIR = REPO_ROOT / "models" / "golden_run"

FEATURE_COLS = [
    "flow_duration", "flow_bytes_per_sec", "flow_pkts_per_sec", "mean_pkt_size",
    "payload_byte_ratio", "pkt_count_ratio", "tcp_syn_ratio", "proto_tcp", "proto_udp",
    "proto_icmp", "proto_other", "temporal_iat_mean", "temporal_iat_cv",
    "temporal_flow_rate_ewma", "temporal_byte_rate_ewma", "temporal_syn_rate_ewma",
    "behavioral_dst_diversity", "behavioral_port_entropy", "behavioral_fanout_ratio",
    "behavioral_unanswered_ratio", "behavioral_src_activity_ewma"
]

class MLPModule(nn.Module):
    def __init__(self, input_dim: int = 21):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

def train_dp_sgd_bounded(
    X_train: np.ndarray,
    y_train: np.ndarray,
    dp_config: DPConfig,
    adv_eps: float = 0.10,
    adv_alpha: float = 0.025,
    adv_steps: int = 7,
):
    """Trains MLP with Poisson sampling, per-example gradient clipping, and feature clamping [-10, 10]."""
    torch.manual_seed(dp_config.seed)
    np.random.seed(dp_config.seed)

    model = MLPModule(21)
    optimizer = torch.optim.Adam(model.parameters(), lr=dp_config.learning_rate)
    criterion = nn.BCEWithLogitsLoss()

    dataset_size = len(X_train)
    batch_size = dp_config.batch_size
    sample_rate = batch_size / dataset_size if dataset_size > 0 else 0.01

    feature_mask = torch.ones(21, dtype=torch.float32)
    feature_mask[17:21] = 0.0 # Freeze protocol indicators

    # Pre-clamp training features to [-10, 10]
    X_train_clamped = np.clip(X_train, -10.0, 10.0)
    X_train_t = torch.tensor(X_train_clamped, dtype=torch.float32)
    y_train_t = torch.tensor(y_train, dtype=torch.float32)

    steps_per_epoch = max(1, int(round(dataset_size / batch_size)))
    total_steps = 0
    actual_batch_sizes = []

    for epoch in range(dp_config.epochs):
        for _ in range(steps_per_epoch):
            # Poisson sampling: each sample selected independently with probability q
            poisson_mask = np.random.binomial(1, sample_rate, size=dataset_size).astype(bool)
            if not np.any(poisson_mask):
                poisson_mask[np.random.choice(dataset_size, size=min(4, dataset_size), replace=False)] = True

            actual_batch_sizes.append(int(np.sum(poisson_mask)))
            xb = X_train_t[poisson_mask].clone()
            yb = y_train_t[poisson_mask].clone()
            b_size = len(xb)

            # Adversarial Batch Generation (PGD-7)
            x_adv = xb.clone().detach()
            x_adv.requires_grad = True

            for _ in range(adv_steps):
                model.eval()
                logits = model(x_adv).squeeze(-1)
                loss = criterion(logits, yb)
                loss.backward()

                with torch.no_grad():
                    grad_sign = x_adv.grad.sign() * feature_mask
                    x_adv = x_adv + adv_alpha * grad_sign
                    eta = torch.clamp(x_adv - xb, min=-adv_eps, max=adv_eps) * feature_mask
                    x_adv = torch.clamp(xb + eta, min=-10.0, max=10.0).detach()
                    x_adv.requires_grad = True

            # DP-SGD Step
            model.train()
            optimizer.zero_grad()

            per_ex_grads = {name: [] for name, param in model.named_parameters() if param.requires_grad}
            model.eval()
            for i in range(b_size):
                x_s = x_adv[i : i + 1]
                y_s = yb[i : i + 1]
                model.zero_grad()
                with torch.set_grad_enabled(True):
                    out_s = model(x_s)
                    l_s = criterion(out_s.squeeze(-1), y_s.float())
                    l_s.backward()
                for name, param in model.named_parameters():
                    if param.requires_grad and param.grad is not None:
                        per_ex_grads[name].append(param.grad.clone().detach())

            with torch.no_grad():
                for name, param in model.named_parameters():
                    if not param.requires_grad:
                        continue
                    grads = torch.stack(per_ex_grads[name], dim=0)
                    flat_grads = grads.view(b_size, -1)
                    norms = torch.norm(flat_grads, p=2, dim=1)
                    clip_factors = torch.clamp(dp_config.max_grad_norm / (norms + 1e-6), max=1.0)
                    view_shape = [b_size] + [1] * (grads.ndim - 1)
                    clipped_grads = grads * clip_factors.view(*view_shape)
                    summed_clipped = torch.sum(clipped_grads, dim=0)
                    noise_std = dp_config.noise_multiplier * dp_config.max_grad_norm
                    noise = torch.randn_like(summed_clipped) * noise_std
                    param.grad = (summed_clipped + noise) / float(b_size)

            optimizer.step()
            total_steps += 1

    epsilon = compute_dp_epsilon(
        steps=total_steps,
        sample_rate=sample_rate,
        noise_multiplier=dp_config.noise_multiplier,
        target_delta=dp_config.target_delta,
    )

    batch_stats = {
        "mean_batch_size": float(np.mean(actual_batch_sizes)),
        "min_batch_size": int(np.min(actual_batch_sizes)),
        "max_batch_size": int(np.max(actual_batch_sizes)),
        "std_batch_size": float(np.std(actual_batch_sizes)),
    }

    return model, epsilon, total_steps, sample_rate, batch_stats

def main():
    print("==========================================================================")
    print("=== TARGETED DP-SGD BOUNDED EVALUATION & ENSEMBLE ATTACK AUDIT ===")
    print("==========================================================================\n")

    # --- 1. ToN-IoT Bounded Preprocessing DP-SGD Rerun ---
    print("--- 1. RERUNNING ToN-IoT DP-SGD WITH BOUNDED PREPROCESSING [-10, 10] ---")
    ton_tr = pd.read_parquet(STAGE3_DIR / "ToN-IoT" / "train.parquet")
    ton_te = pd.read_parquet(STAGE3_DIR / "ToN-IoT" / "test.parquet")
    scaler_ton = joblib.load(MODELS_DIR / "ToN-IoT" / "scaler.joblib")

    X_tr_ton = np.clip(scaler_ton.transform(ton_tr[FEATURE_COLS].values), -10.0, 10.0)
    X_te_ton = np.clip(scaler_ton.transform(ton_te[FEATURE_COLS].values), -10.0, 10.0)
    y_tr_ton = ton_tr["label"].values
    y_te_ton = ton_te["label"].values

    attack_mask = (y_te_ton == 1)
    X_att_ton = X_te_ton[attack_mask]
    y_att_ton = y_te_ton[attack_mask]

    ton_dp_results = []
    continuous_mask = torch.ones(21, dtype=torch.float32)
    continuous_mask[7:11] = 0.0

    for noise_mult in [0.0, 0.5, 1.0, 2.0]:
        dp_cfg = DPConfig(
            max_grad_norm=1.0,
            noise_multiplier=noise_mult,
            target_delta=1e-5,
            epochs=10,
            batch_size=64,
            seed=42
        )
        model_dp, eps_prv, actual_steps, sample_rate, b_stats = train_dp_sgd_bounded(
            X_tr_ton, y_tr_ton, dp_config=dp_cfg
        )

        model_dp.eval()
        with torch.no_grad():
            p_dp = torch.sigmoid(model_dp(torch.tensor(X_te_ton, dtype=torch.float32))).squeeze().numpy()
        auc_dp = float(roc_auc_score(y_te_ton, p_dp))

        # PGD-10 ASR
        if len(X_att_ton) > 0:
            X_att_t = torch.tensor(X_att_ton, dtype=torch.float32)
            y_att_t = torch.tensor(y_att_ton, dtype=torch.float32)
            x_min = torch.tensor(np.min(X_tr_ton, axis=0), dtype=torch.float32)
            x_max = torch.tensor(np.max(X_tr_ton, axis=0), dtype=torch.float32)

            X_adv_dp = pgd_attack(
                model_dp, X_att_t, y_att_t,
                epsilon=0.10, alpha=0.025, steps=10,
                continuous_mask=continuous_mask, x_min=x_min, x_max=x_max
            ).numpy()
            with torch.no_grad():
                p_adv = torch.sigmoid(model_dp(torch.tensor(X_adv_dp, dtype=torch.float32))).squeeze().numpy()
            asr_dp = float(np.mean(p_adv < 0.5))
        else:
            asr_dp = 0.0

        eps_str = f"{eps_prv:.2f}" if eps_prv != float("inf") else "inf"
        print(f"  [ToN-IoT DP noise={noise_mult:.1f}] Opacus PRV eps={eps_str:6s} | ROC-AUC: {auc_dp:.6f} | ASR: {asr_dp*100:5.2f}% | Steps: {actual_steps} | Mean Batch: {b_stats['mean_batch_size']:.1f}")

        ton_dp_results.append({
            "noise_multiplier": noise_mult,
            "epsilon": eps_prv,
            "delta": 1e-5,
            "roc_auc": auc_dp,
            "pgd10_asr": asr_dp,
            "actual_steps": actual_steps,
            "sampling_rate": sample_rate,
            "batch_stats": b_stats
        })

    # --- 2. Ensemble-Aware Black-Box Decision Attack on Option C ---
    print("\n--- 2. EVALUATING ENSEMBLE-AWARE DECISION ATTACK ON OPTION C ---")
    ensemble_attack_results = {}
    
    for ds in DATASETS:
        ds_models_dir = MODELS_DIR / ds
        te_df = pd.read_parquet(STAGE3_DIR / ds / "test.parquet")
        tr_df = pd.read_parquet(STAGE3_DIR / ds / "train.parquet")
        
        scaler = joblib.load(ds_models_dir / "scaler.joblib")
        rf = joblib.load(ds_models_dir / "rf_model.joblib")
        mlp_rob = MLPModule(21)
        mlp_rob.load_state_dict(torch.load(ds_models_dir / "mlp_rob.pt"))
        mlp_rob.eval()

        X_te = np.clip(scaler.transform(te_df[FEATURE_COLS].values), -10.0, 10.0)
        y_te = te_df["label"].values

        attack_mask = (y_te == 1)
        X_att = X_te[attack_mask][:50]
        y_att = y_te[attack_mask][:50]

        if len(X_att) > 0:
            # Ensemble-aware Zeroth-Order Gradient/Decision Perturbation Attack
            # Generates perturbations targeting the fused Option C probability directly:
            # P_OptionC = 0.7 * P_RF + 0.3 * P_MLP_Adv
            np.random.seed(42)
            n_samples = len(X_att)
            adv_evasion_count = 0

            for i in range(n_samples):
                x_orig = X_att[i]
                # Matrix of 20 perturbation candidates
                noise = np.random.uniform(-0.10, 0.10, size=(20, 21))
                noise[:, 7:11] = 0.0 # Freeze discrete protocol flags
                x_cand = np.clip(x_orig + noise, -10.0, 10.0)

                p_rf_cand = rf.predict_proba(x_cand)[:, 1]
                with torch.no_grad():
                    p_rob_cand = torch.sigmoid(mlp_rob(torch.tensor(x_cand, dtype=torch.float32))).squeeze().numpy()

                p_opt_c_cand = 0.7 * p_rf_cand + 0.3 * p_rob_cand
                if np.min(p_opt_c_cand) < 0.5:
                    adv_evasion_count += 1

            ensemble_asr = adv_evasion_count / float(n_samples)
            ensemble_attack_results[ds] = ensemble_asr
            print(f"  [{ds:15s}] Ensemble-Aware Black-Box Decision Attack ASR: {ensemble_asr*100:5.2f}%")

    # Update Privacy Evidence Summary JSON
    privacy_summary_path = REPO_ROOT / "reports" / "privacy" / "privacy_evidence_summary.json"
    with open(privacy_summary_path, "r") as f:
        priv_json = json.load(f)

    priv_json["dp_experiments"]["ToN-IoT"] = ton_dp_results
    priv_json["privacy_guarantee_scope"] = "DP-trained Neural Stream Branch Only (Not RF or Full Option C Ensemble)"
    priv_json["ensemble_aware_attack_asr"] = ensemble_attack_results

    with open(privacy_summary_path, "w") as f:
        json.dump(priv_json, f, indent=2)
    print("\nSaved updated reports/privacy/privacy_evidence_summary.json")

    # Update Golden Run Manifest
    manifest_path = REPO_ROOT / "reports" / "golden_run_manifest.json"
    with open(manifest_path, "r") as f:
        manifest = json.load(f)

    manifest["privacy_summary"] = priv_json
    manifest["ensemble_aware_attack_asr"] = ensemble_attack_results
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    print("Saved updated reports/golden_run_manifest.json")

if __name__ == "__main__":
    main()
