s = r"$P_{\text{MLP\_Adv}}$"
pattern1 = "P\\_"  # 3 chars: P, \, _
pattern2 = r"P\_" # 3 chars: P, \, _

print("s:", s)
print("pattern1:", repr(pattern1))
print("pattern1 in s:", pattern1 in s)
print("pattern2:", repr(pattern2))
print("pattern2 in s:", pattern2 in s)

print("Exact match for 'P\\_':")
print("P\\_" in r"$P_{\text{RF}}$")
print("P\\_" in r"$P_{\text{MLP\_Adv}}$")
print("P\\_" in r"$P_{\text{MLP_Adv}}$")
