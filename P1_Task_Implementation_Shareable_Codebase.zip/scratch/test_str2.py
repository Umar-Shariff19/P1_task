s = r"$P_{\text{MLP\_Adv}}$"
pat = r"P\_"

print("s repr:", repr(s))
print("pat repr:", repr(pat))
print("pat in s:", pat in s)

for i in range(len(s) - len(pat) + 1):
    sub = s[i:i+len(pat)]
    if sub == pat:
        print(f"Match found at index {i}: {repr(sub)}")
    else:
        print(f"Index {i}: {repr(sub)}")
