"""Updates existing presentation decks with presentation-quality visual Results & Analysis slides.
"""

from pathlib import Path
import pptx
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor


SLIDE1_PNG = Path("PPT/results_slide1_experimental_results.png")
SLIDE2_PNG = Path("PPT/results_slide2_robustness_validation.png")


def update_deck(ppt_path, slide1_idx, slide2_idx):
    """Embeds PNG graphics onto specified slide indices in a presentation."""
    prs = Presentation(str(ppt_path))
    
    # Update Slide 1 (Experimental Results & Analysis)
    if slide1_idx < len(prs.slides):
        slide1 = prs.slides[slide1_idx]
        # Clear shapes except title if present, or add graphic over slide
        slide1.shapes.add_picture(str(SLIDE1_PNG), Inches(0.5), Inches(1.2), Inches(9.0), Inches(5.3))
        
    # Update Slide 2 (Robustness & System Validation)
    if slide2_idx < len(prs.slides):
        slide2 = prs.slides[slide2_idx]
        slide2.shapes.add_picture(str(SLIDE2_PNG), Inches(0.5), Inches(1.2), Inches(9.0), Inches(5.3))
        
    prs.save(str(ppt_path))
    print(f"Updated presentation: {ppt_path}")


if __name__ == "__main__":
    # Update 11-slide deck (Slides 8 and 9, 0-indexed: 7 and 8)
    update_deck(Path("PPT/IoT_IDS_Major_Project_Phase2_Review1.pptx"), 7, 8)
    
    # Update 44-slide detailed deck (Slides 22 and 32, 0-indexed: 21 and 31)
    update_deck(Path("PPT/IoT_IDS_Major_Project_Phase2_Review1_Detailed.pptx"), 21, 31)
