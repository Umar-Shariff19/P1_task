import os

ab_path = r"c:\Users\umari\Documents\P1_task_Implementation\ieee_paper_draft\sections\abstract.tex"
intro_path = r"c:\Users\umari\Documents\P1_task_Implementation\ieee_paper_draft\sections\introduction.tex"

with open(ab_path, 'rb') as f:
    ab_content = f.read().decode('utf-8')

with open(intro_path, 'rb') as f:
    intro_content = f.read().decode('utf-8')

# 1. FORBIDDEN PATTERN COUNTS
forbidden = {
    "\\\\%": ab_content.count("\\%") + intro_content.count("\\%"),
    "\\textbf{**": ab_content.count("\\textbf{**") + intro_content.count("\\textbf{**"),
    "P\\_": ab_content.count("P\\_{") + intro_content.count("P\\_{"),
    "\\\\_": ab_content.count("\\\\_") + intro_content.count("\\\\_"),
    "**": ab_content.count("**") + intro_content.count("**")
}

# 2. REQUIRED CORRECT PATTERNS
required = {
    "$86.67\\%$": "$86.67\\%$" in ab_content,
    "$73.13\\%$": "$73.13\\%$" in ab_content,
    "$0.00\\%$": "$0.00\\%$" in ab_content,
    "\\textbf{Cross-Dataset Performance Variation:}": "\\textbf{Cross-Dataset Performance Variation:}" in intro_content,
    "\\textbf{Adversarial Evasion Sensitivity:}": "\\textbf{Adversarial Evasion Sensitivity:}" in intro_content,
    "$P_{\\text{RF}}$": "$P_{\\text{RF}}$" in intro_content,
    "$P_{\\text{MLP\\_Adv}}$": "$P_{\\text{MLP\\_Adv}}$" in intro_content,
    "$0.7 P_{\\text{RF}} + 0.3 P_{\\text{MLP\\_Adv}}$": "$0.7 P_{\\text{RF}} + 0.3 P_{\\text{MLP\\_Adv}}$" in intro_content
}

print("=== FORBIDDEN PATTERN COUNTS ===")
for k, v in forbidden.items():
    print(f"  {k} = {v}")

print("\n=== REQUIRED CORRECT PATTERNS ===")
for k, v in required.items():
    print(f"  {k}: {'EXISTS' if v else 'MISSING'}")

# 3. DIRECT FILE LINE PROOF
print("\n=== DIRECT FILE LINE PROOF ===")

print("\n[abstract.tex - Percentage Line]:")
for line in ab_content.splitlines():
    if "86.67" in line:
        print(line)

print("\n[introduction.tex - Bold Headings]:")
for line in intro_content.splitlines():
    if "\\textbf{" in line:
        print(line.strip())

print("\n[introduction.tex - RF/MLP Notation & Ensemble Formula Line]:")
for line in intro_content.splitlines():
    if "weighted soft-voting" in line:
        print(line.strip())
