import os

ab_path = r"c:\Users\umari\Documents\P1_task_Implementation\ieee_paper_draft\sections\abstract.tex"
intro_path = r"c:\Users\umari\Documents\P1_task_Implementation\ieee_paper_draft\sections\introduction.tex"

with open(ab_path, 'r', encoding='utf-8') as f:
    ab_content = f.read()

with open(intro_path, 'r', encoding='utf-8') as f:
    intro_content = f.read()

full_text = ab_content + intro_content

# 1. Double backslash % check (literal \\%)
double_backslash_percent = full_text.count("\\\\%")

# 2. \textbf{** check
textbf_markdown = full_text.count("\\textbf{**")

# 3. P\_ escaped subscript check
p_escaped = full_text.count("P\\_{")

# 4. \\\_ double escaped underscore check
double_escaped_underscore = full_text.count("\\\\_")

# 5. Markdown ** check
markdown_stars = full_text.count("**")

print("=== EXACT FORBIDDEN PATTERN AUDIT ===")
print(f"  \\\\% (double backslash percent) = {double_backslash_percent}")
print(f"  \\textbf{{** (markdown in bold)   = {textbf_markdown}")
print(f"  P\\_{{ (escaped subscript)       = {p_escaped}")
print(f"  \\\\_ (double escaped underscore) = {double_escaped_underscore}")
print(f"  ** (markdown stars)            = {markdown_stars}")

print("\n=== REQUIRED CORRECT PATTERNS ===")
print("  $86.67\\%$:", "$86.67\\%" in ab_content)
print("  $73.13\\%$:", "$73.13\\%" in ab_content)
print("  $0.00\\%$:", "$0.00\\%" in ab_content)
print("  \\textbf{Cross-Dataset Performance Variation:}:", "\\textbf{Cross-Dataset Performance Variation:}" in intro_content)
print("  \\textbf{Adversarial Evasion Sensitivity:}:", "\\textbf{Adversarial Evasion Sensitivity:}" in intro_content)
print("  $P_{\\text{RF}}$:", "$P_{\\text{RF}}$" in intro_content)
print("  $P_{\\text{MLP\\_Adv}}$:", "$P_{\\text{MLP\\_Adv}}$" in intro_content)
print("  $0.7 P_{\\text{RF}} + 0.3 P_{\\text{MLP\\_Adv}}$:", "$0.7 P_{\\text{RF}} + 0.3 P_{\\text{MLP\\_Adv}}$" in intro_content)
