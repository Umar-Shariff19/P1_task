import os
import re

tex_dir = r"ieee_paper_draft\sections"
bib_path = r"ieee_paper_draft\references.bib"

# 1. Parse bib keys
bib_keys = set()
with open(bib_path, "r", encoding="utf-8") as f:
    for line in f:
        match = re.match(r'^\@\w+\{\s*([^,]+),', line.strip())
        if match:
            bib_keys.add(match.group(1).strip())

print(f"Total BibTeX keys in references.bib: {len(bib_keys)}")
print("BibTeX Keys:", sorted(list(bib_keys)))
print("=" * 70)

# 2. Parse cite keys from all tex files
cite_map = {}
all_cites = set()

for root, _, files in os.walk(r"ieee_paper_draft"):
    for fname in files:
        if fname.endswith(".tex"):
            fpath = os.path.join(root, fname)
            with open(fpath, "r", encoding="utf-8") as tf:
                content = tf.read()
                matches = re.findall(r'\\cite\{([^}]+)\}', content)
                for m in matches:
                    keys = [k.strip() for kk in m.split(',') for k in kk.split()]
                    for k in keys:
                        if k:
                            all_cites.add(k)
                            cite_map.setdefault(k, set()).add(fname)

print(f"Total unique \\cite{{}} keys in paper: {len(all_cites)}")
print("Cited Keys:", sorted(list(all_cites)))
print("=" * 70)

# 3. Check for missing bib keys (broken citations)
missing = all_cites - bib_keys
if missing:
    print("CRITICAL ERROR: The following cited keys are MISSING from references.bib:")
    for k in missing:
        print(f"  - {k} (cited in {cite_map[k]})")
else:
    print("SUCCESS: 100% of cited keys exist in references.bib!")

# 4. Check for uncited bib keys
uncited = bib_keys - all_cites
if uncited:
    print("Uncited keys in references.bib:", sorted(list(uncited)))
else:
    print("100% of references.bib keys are cited in the manuscript!")

# 5. Citation usage per file
print("=" * 70)
print("Citation usage per file:")
for fname in sorted(list(set(f for files in cite_map.values() for f in files))):
    file_cites = [k for k, files in cite_map.items() if fname in files]
    print(f"  {fname}: {len(file_cites)} citations -> {sorted(file_cites)}")
