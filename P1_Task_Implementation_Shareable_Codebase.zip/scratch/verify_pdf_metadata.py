import os
import pypdf
import re
import json

pdf_dir = r"paper_support\Literature paper"

file_map = [
    ("paper(2).pdf / paper19.pdf", ["paper(2).pdf", "paper19.pdf"]),
    ("paper1", ["paper1-IET Information Security - 2025 - Ma - Backdoor Attack and Defense Methods for AI Based IoT Intrusion Detection System.pdf"]),
    ("paper10 / paper18", ["paper10.pdf", "paper18.pdf"]),
    ("paper11", ["paper11.pdf"]),
    ("paper13", ["paper13.pdf"]),
    ("paper14", ["paper14.pdf"]),
    ("paper15 / paper20", ["paper15.pdf", "paper20.pdf"]),
    ("paper16", ["paper16.pdf"]),
    ("paper17", ["paper17.pdf"]),
    ("paper2", ["paper2.pdf"]),
    ("paper21", ["paper21.pdf"]),
    ("paper22", ["paper22.pdf"]),
    ("paper23", ["paper23.pdf"]),
    ("paper24 / paper3", ["paper24.pdf", "paper3.pdf"]),
    ("paper25", ["paper25.pdf"]),
    ("paper4", ["paper4.pdf"]),
    ("paper5", ["paper5.pdf"]),
    ("paper6", ["paper6.pdf"]),
    ("paper7", ["paper7.pdf"]),
    ("paper8", ["paper8.pdf"]),
    ("paper9", ["paper9.pdf"])
]

print(f"Total unique paper groups: {len(file_map)}")

results = []
for label, filenames in file_map:
    primary_fn = filenames[0]
    path = os.path.join(pdf_dir, primary_fn)
    reader = pypdf.PdfReader(path)
    p1 = reader.pages[0].extract_text() or ""
    p2 = reader.pages[1].extract_text() or "" if len(reader.pages) > 1 else ""
    full_first = (p1 + "\n" + p2)[:2000]
    
    results.append({
        "label": label,
        "filenames": filenames,
        "text_sample": full_first
    })

with open(r"scratch\pdf_forensic_extracts.json", "w", encoding="utf-8") as out:
    json.dump(results, out, indent=2)

print("Extracted PDF text samples for all 21 unique paper groups.")
